package com.ayuv.sec.backend.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.ayuv.sec.backend.utils.BasicAuthenticationUtil;

import lombok.extern.log4j.Log4j2;

/**
 * The Class BackendAuthenticationFilter.
 * 
 */
@Component
@Order(1)

/** The Constant log. */
@Log4j2
public class BackendAuthenticationFilter implements Filter {

	/** The access key. */
	@Value("${api.access.key}")
	private String accessKey;

	/** The access value. */
	@Value("${api.access.value}")
	private String accessValue;

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
	 * javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		log.info("Start ApiBasicAuthenticationFilter");
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;

		final String authorization = httpRequest.getHeader(BasicAuthenticationUtil.BASCI_AUTH);

		if (authorization != null && authorization.toLowerCase().startsWith("basic")
				&& BasicAuthenticationUtil.isAutenticationSuccessfull(authorization, accessKey, accessValue)) {
			log.info("End ApiBasicAuthenticationFilter request redirected");
			chain.doFilter(request, response);
		} else {
			log.info("End ApiBasicAuthenticationFilter Access Error");
			httpResponse.sendError(403, "The access to the requested resources is forbidden.");
		}

	}

}
