package com.ayuv.sec.backend.utils;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

import lombok.extern.log4j.Log4j2;

/**
 * The Class BasicAuthenticationUtil.
 *
 */
@Log4j2
public class BasicAuthenticationUtil {

    /** The Constant BASCI_AUTH. */
    public static final String BASCI_AUTH = "BASICAUTH";

    /**
     * isAutenticationSuccessfull
     * 
     * @param authorization
     * @param accesskey
     * @param accessvalue
     * @return
     */
    public static boolean isAutenticationSuccessfull(String authorization, String accesskey, String accessvalue) {
        // Authorization: Basic base64credentials
        String base64Credentials = authorization.substring("Basic".length()).trim();
        byte[] credDecoded = Base64.getDecoder().decode(base64Credentials);
        String credentials = new String(credDecoded, StandardCharsets.UTF_8);
        // credentials = username:password
        final String[] values = credentials.split(":", 2);
        
        if (values[0] != null && values[1] != null && values[0].equals(accesskey) && values[1].equals(accessvalue)) {
            log.info("Authentication Success");
            return true;
        } else {
            log.info("Authentication Failed");
            return false;
        }
    }
}
