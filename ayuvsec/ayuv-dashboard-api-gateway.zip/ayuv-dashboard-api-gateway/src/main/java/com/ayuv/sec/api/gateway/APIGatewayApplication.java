package com.ayuv.sec.api.gateway;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;


import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * The Class APIGatewayApplication.
 * 

 * 
 */
@SpringBootApplication
@ComponentScan(basePackages = { "com.ayuv.sec.api.framework.core.context.client", "com.ayuv.sec.api.framework.core.context.controller",
        "com.ayuv.sec.api.framework.core.exception", "com.ayuv.sec.api.framework.core.data.jdbc", "com.ayuv.sec.api.auth", "com.ayuv.sec.api.gateway" })
@PropertySource(value = "classpath:access.properties", ignoreResourceNotFound = true)
@EnableSwagger2
@EnableZuulProxy
public class APIGatewayApplication {

    @Value("${application.name}")
    private String applicationName;
    @Value("${build.version}")
    private String version = "1.0";
    @Value("${build.timestamp}")
    private String timestamp = DateFormatUtils.format(new Date(), "yyyyMMddHHmmss");

    public static void main(String[] args) {
        SpringApplication application = new SpringApplication(APIGatewayApplication.class);
        // customize include and exclude paths so that Context interceptor only intercepts API calls
        List<String> customInterceptorIncludePath = Collections.singletonList("/api/**");
        List<String> customInterceptorExcludePath = Collections.singletonList("/api/auth/**");

        Properties properties = new Properties();
        properties.put("context.interceptor.custom.include.path", customInterceptorIncludePath);
        properties.put("context.interceptor.custom.exclude.path", customInterceptorExcludePath);
        application.setDefaultProperties(properties);
        application.run(args);
    }
}
