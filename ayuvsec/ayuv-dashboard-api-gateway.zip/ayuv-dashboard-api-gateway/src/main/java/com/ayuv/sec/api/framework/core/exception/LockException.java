package com.ayuv.sec.api.framework.core.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * The Class LockException.
 * 

 * 
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class LockException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /**
     * Instantiates a new lock exception.
     *
     * @param msg the msg
     */
    public LockException(String msg) {
        super(msg);
    }
}
