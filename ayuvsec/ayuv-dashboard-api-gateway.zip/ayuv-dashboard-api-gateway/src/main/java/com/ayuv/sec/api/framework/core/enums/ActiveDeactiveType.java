package com.ayuv.sec.api.framework.core.enums;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Enum ActiveDeactiveType.
 * 

 * 
 */
public enum ActiveDeactiveType {

    /** The yes. */
    @JsonProperty("A")
    ACTIVE("A", "Active"),

    /** The no. */
    @JsonProperty("D")
    DEACTIVE("D", "Deactive");

    /** The type. */
    private final String type;

    /** The desc. */
    private final String desc;

    /**
     * Instantiates a new active deactive type.
     *
     * @param type the type
     * @param desc the desc
     */
    ActiveDeactiveType(String type, String desc) {
        this.type = type;
        this.desc = desc;
    }

    /**
     * Gets the type by type.
     *
     * @param type the type
     * @return the type by type
     */
    public static ActiveDeactiveType getTypeByType(String type) {
        for (ActiveDeactiveType ref : ActiveDeactiveType.values()) {
            if (ref.type.equals(type)) {
                return ref;
            }
        }
        return null;
    }

    /**
     * Gets the type.
     *
     * @return the type
     */
    public String getType() {
        return this.type;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return this.desc;
    }

}
