package com.ayuv.sec.api.auth.utils;

import java.nio.charset.Charset;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ayuv.sec.api.framework.core.enums.TokenType;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

/**
 * The Class TokenBuilder.
 * 
 * 
 * 
 */
@Component
public class TokenBuilder {

	/**
	 * The signing key in bytes.
	 */
	private static byte[] signingKeyInBytes;

	/**
	 * Instantiates a new token builder.
	 *
	 * @param signingKey the signing key
	 * @param expiration the expiration
	 */


	/**
	 * The access token expiration.
	 */
	private static long accesstokenexpiration;

	/**
	 * The refresh token expiration.
	 */
	private static long refreshtokenexpiration;

	public TokenBuilder(@Value("${jsonwebtoken.signingkey}") String signingKey,
			@Value("${accesstoken.expiration}") long accesstokenexpiration,
			@Value("${refreshtoken.expiration}") long refreshtokenexpiration) {
		TokenBuilder.signingKeyInBytes = signingKey.getBytes(Charset.forName("UTF-8"));
		TokenBuilder.accesstokenexpiration = accesstokenexpiration;
		TokenBuilder.refreshtokenexpiration = refreshtokenexpiration;
	}

	/**
	 * Creates the token.
	 *
	 * @param jsonData the json data
	 * @return the string
	 */
	public static String createToken(String jsonData, TokenType tokenType) {
		if (tokenType.equals(TokenType.ACCESS_TOKEN)) {
			return Jwts.builder().setSubject(jsonData)
					.setExpiration(new Date(System.currentTimeMillis() + accesstokenexpiration))
					.signWith(SignatureAlgorithm.HS512, signingKeyInBytes).compact();
		}
		if (tokenType.equals(TokenType.REFRESH_TOKEN)) {
			return Jwts.builder().setSubject(jsonData)
					.setExpiration(new Date(System.currentTimeMillis() + refreshtokenexpiration))
					.signWith(SignatureAlgorithm.HS512, signingKeyInBytes).compact();
		}
		return null;
	}

	/**
	 * Gets the json data.
	 *
	 * @param token the token
	 * @return the json data
	 */
	public static String getJsonData(String token) {
		if (token != null && !token.isEmpty()) {
			return Jwts.parser().setSigningKey(signingKeyInBytes).parseClaimsJws(token).getBody().getSubject();
		}
		return null;
	}
}
