package com.ayuv.sec.api.framework.core.exception;

/**
 * The Class ReferenceException.
 * 

 * 
 */
public class ReferenceException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /**
     * Instantiates a new reference exception.
     *
     * @param errorMessage the error message
     * @param err          the err
     */
    public ReferenceException(String errorMessage, Throwable err) {
        super(errorMessage, err);
    }
}
