package com.ayuv.sec.api.framework.core.exception;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ErrorDetail.
 * 

 * 
 */
@Data
@NoArgsConstructor
public class ErrorDetail {

    /** The error code. */
    private String errorCode;

    /** The error field. */
    private String errorField;

    /** The error message. */
    private String errorMessage;

    /**
     * Instantiates a new error detail.
     *
     * @param errorCode    the error code
     * @param errorField   the error field
     * @param errorMessage the error message
     */
    public ErrorDetail(String errorCode, String errorField, String errorMessage) {
        this.errorCode = errorCode;
        this.errorField = errorField;
        this.errorMessage = errorMessage;
    }
}
