package com.ayuv.sec.api.framework.utils;

import com.ayuv.sec.api.framework.core.hashcode.IHashCode;

/**
 * The Class HashCodeUtils.
 * 

 * 
 */
public class HashCodeUtils {

    /**
     * Gets the hash code.
     *
     * @param result             the result
     * @param hashObject         the hash object
     * @param includeMinorChange the include minor change
     * @return the hash code
     */
    public static final int getHashCode(int result, Object hashObject, Boolean includeMinorChange) {
        final int prime = 31;
        return ((hashObject == null || (hashObject instanceof String && hashObject.toString().isEmpty()) ? result
                : ((hashObject instanceof IHashCode) ? ((IHashCode) hashObject).getHash(includeMinorChange)
                        : (prime * result) + hashObject.hashCode())));
    }
}
