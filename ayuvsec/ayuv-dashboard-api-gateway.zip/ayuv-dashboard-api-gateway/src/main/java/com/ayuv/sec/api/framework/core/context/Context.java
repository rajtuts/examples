package com.ayuv.sec.api.framework.core.context;

import java.util.UUID;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;

/**
 * The Class Context.
 * 

 * 
 */
@Data
public class Context {

    /** The trans id. */
    @Setter(AccessLevel.NONE)
    private UUID transId = UUID.randomUUID();

    /** The username. */
    private String username;

    /**
     * Instantiates a new context.
     */
    public Context() {
    }

    /**
     * Instantiates a new context.
     *
     * @param source the source
     */
    public Context(Context source) {
        this.transId = UUID.randomUUID();
        this.username = source.getUsername();
    }

    /**
     * Gets the trans id.
     *
     * @return the trans id
     */
    public UUID getTransId() {
        return transId;
    }

}
