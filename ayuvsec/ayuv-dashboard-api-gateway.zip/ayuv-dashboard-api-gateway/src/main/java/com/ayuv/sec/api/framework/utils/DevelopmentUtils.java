package com.ayuv.sec.api.framework.utils;

/**
 * The Class DevelopmentUtils.
 */
public class DevelopmentUtils {

    /**
     * Checks if is debug.
     *
     * @return the boolean
     */
    public static Boolean isDebug() {
        return java.lang.management.ManagementFactory.getRuntimeMXBean().getInputArguments().toString().indexOf("-agentlib:jdwp") > 0;
    }
}
