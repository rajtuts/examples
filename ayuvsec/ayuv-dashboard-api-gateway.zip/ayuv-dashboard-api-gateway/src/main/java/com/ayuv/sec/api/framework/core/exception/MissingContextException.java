package com.ayuv.sec.api.framework.core.exception;

import org.springframework.security.core.AuthenticationException;

/**
 * The Class MissingContextException.
 * 

 * 
 */
public class MissingContextException extends AuthenticationException {

    private static final long serialVersionUID = 6805685432618144044L;

    /**
     * Instantiates a new missing context exception.
     *
     * @param msg the msg
     */
    public MissingContextException(String msg) {
        super(msg);
    }

}
