package com.ayuv.sec.api.auth.data.dao;

import com.ayuv.sec.api.auth.dto.UserLoginDto;

public interface UserLoginDao {

	public void updateUserLastActiveTime(String userId);

    public void removeInactiveLogin(String userId);

    public UserLoginDto authenticateUserDetails(String username, String password);
    
    public UserLoginDto authenticateUserDetailsbyRefreshToken(String username);
    
    public void updateUserLogin(UserLoginDto userLoginDto);
    
    public boolean validateAccessToken(String userId, long timeoutInSeconds, String token);
    
    public boolean validateRefreshToken(String userId, long timeoutInSeconds, String token);

}