package com.ayuv.sec.api.framework.logging;

/**
 * The Class LogContextDataHolder.
 * 

 * 
 */
public class LogContextDataHolder {

    /** The log context data thread local. */
    private static ThreadLocal<LogContextData> logContextDataThreadLocal = new ThreadLocal<>();

    /**
     * Sets the log context data.
     *
     * @param logContextData the log context data
     */
    public static void set(LogContextData logContextData) {
        logContextDataThreadLocal.set(logContextData);
    }

    /**
     * Gets the log context data.
     *
     * @return the log context data
     */
    public static LogContextData get() {
        return logContextDataThreadLocal.get();
    }

    /**
     * Removes the log context data.
     */
    public static void remove() {
        logContextDataThreadLocal.remove();
    }

    /**
     * Instantiates a new log context data holder.
     */
    private LogContextDataHolder() {
    }

}
