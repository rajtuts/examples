package com.ayuv.sec.api.gateway.config;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.web.servlet.error.ErrorViewResolver;
import org.springframework.boot.web.servlet.DelegatingFilterProxyRegistrationBean;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.env.Environment;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import org.springframework.web.filter.ForwardedHeaderFilter;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.ayuv.sec.api.gateway.filter.AuthenticationFilter;
import com.ayuv.sec.api.gateway.filter.XSSFilter;

/**
 * The Class WebConfig.
 * 

 * 
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    /**
     * The env.
     */
    @Autowired
    private Environment env;

    /**
     * Dispatcher servlet.
     *
     * @return the dispatcher servlet
     */
    @Bean
    public DispatcherServlet dispatcherServlet() {
        return new DispatcherServlet();
    }

    /**
     * Servlet registration bean.
     *
     * @return the servlet registration bean
     */
    @Bean
    public ServletRegistrationBean<DispatcherServlet> servletRegistrationBean() {
        ServletRegistrationBean<DispatcherServlet> servletRegistrationBean = new ServletRegistrationBean<>(dispatcherServlet(), "/*");
        servletRegistrationBean.setLoadOnStartup(0);
        return servletRegistrationBean;
    }

    /**
     * Cors filter.
     *
     * @return the cors filter
     */
    @Bean
    public CorsFilter corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowCredentials(true);
        config.addAllowedOrigin("*");
        config.addAllowedHeader("*");
        config.addAllowedMethod("OPTIONS");
        config.addAllowedMethod("GET");
        config.addAllowedMethod("POST");
        config.addAllowedMethod("PUT");
        config.addAllowedMethod("DELETE");
        source.registerCorsConfiguration("/**", config);
        return new CorsFilter(source);
    }

    /**
     * Authentication filter.
     *
     * @return the authentication filter
     */
    @Bean
    public AuthenticationFilter authenticationFilter() {
        return new AuthenticationFilter();
    }

    /**
     * Authentication filter filter proxy.
     *
     * @return the delegating filter proxy registration bean
     */
    @Bean
    public DelegatingFilterProxyRegistrationBean authenticationFilterFilterProxy() {
        DelegatingFilterProxyRegistrationBean delegatingFilterProxyRegistrationBean = new DelegatingFilterProxyRegistrationBean(
                "authenticationFilter", servletRegistrationBean());
        delegatingFilterProxyRegistrationBean.setOrder(1);
        return delegatingFilterProxyRegistrationBean;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.web.servlet.config.annotation.WebMvcConfigurer#
     * addResourceHandlers(org.springframework.web.servlet.config.annotation. ResourceHandlerRegistry)
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/assets/**").addResourceLocations("classpath:/static/assets/")
                .setCacheControl(CacheControl.maxAge(getResourceCacheMaxAge(), TimeUnit.DAYS));
        registry.addResourceHandler("/build/**").addResourceLocations("classpath:/static/build/")
                .setCacheControl(CacheControl.maxAge(getResourceCacheMaxAge(), TimeUnit.DAYS));
    }

    /**
     * Allow page to refresh
     *
     * @return the ErrorViewResolver
     */
    @Bean
    ErrorViewResolver supportPathBasedLocationStrategyWithoutHashes() {
        return new ErrorViewResolver() {
            @Override
            public ModelAndView resolveErrorView(HttpServletRequest request, HttpStatus status, Map<String, Object> model) {
                return status == HttpStatus.NOT_FOUND ? new ModelAndView("index.html", Collections.<String, Object>emptyMap(), HttpStatus.OK) : null;
            }
        };
    }

    /**
     * Gets the resource cache max age.
     *
     * @return the resource cache max age
     */
    private long getResourceCacheMaxAge() {
        Long maxAge = env.getProperty("ui.resource.cache.maxage", Long.class);
        if (maxAge != null) {
            return maxAge;
        } else {
            return 1;
        }
    }

    /**
     * Forwarded header filter.
     *
     * @return the filter registration bean
     */
    @Bean
    public FilterRegistrationBean<ForwardedHeaderFilter> forwardedHeaderFilter() {
        final FilterRegistrationBean<ForwardedHeaderFilter> filterRegistrationBean = new FilterRegistrationBean<>();
        filterRegistrationBean.setFilter(new ForwardedHeaderFilter());
        filterRegistrationBean.setOrder(Ordered.HIGHEST_PRECEDENCE);
        return filterRegistrationBean;
    }

    /**
     * Xss prevent filter.
     *
     * @return the filter registration bean
     */
    @Bean
    public FilterRegistrationBean<XSSFilter> xssPreventFilter() {
        FilterRegistrationBean<XSSFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(new XSSFilter());
        registrationBean.addUrlPatterns("/*");
        return registrationBean;
    }

}
