package com.ayuv.sec.api.framework.core.config;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validator;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.MethodParameter;
import org.springframework.stereotype.Component;

import com.ayuv.sec.api.framework.core.annotation.ValidParam;

/**
 * The Class ValidateAspect.
 * 

 * 
 */
@Aspect
@Component
public class ValidateAspect {

    @Autowired
    Validator validator;

    /**
     * Instantiates a new validate aspect.
     */
    public ValidateAspect() {
    }

    /**
     * Validate.
     *
     * @param pjp the pjp
     * @return the object
     * @throws Throwable the throwable
     */
    @Around("execution(* *(.., @com.ayuv.sec.api.framework.core.annotation.ValidParam (*), ..))")
    public Object validate(ProceedingJoinPoint pjp) throws Throwable {
        MethodSignature methodSignature = (MethodSignature) pjp.getSignature();
        List<MethodParameter> methodParameters = getMethodParameters(methodSignature);
        for (int i = 0; i < methodParameters.size(); i++) {
            MethodParameter parameter = methodParameters.get(i);
            if (parameter.getParameter().getDeclaredAnnotation(ValidParam.class) != null) {
                // initial the error Set based on the bean type of validator
                Set<ConstraintViolation<Object>> errors = new HashSet<>();
                Object target = pjp.getArgs()[methodParameters.indexOf(parameter)];
                if (target instanceof ArrayList) {
                    ValidateListWrapper wrapper = ValidateListWrapper.builder().wrapperList((ArrayList) target).build();
                    errors.addAll(validator.validate(wrapper));
                } else {
                    errors.addAll(validator.validate(target));
                }
                if (!errors.isEmpty()) {
                    // For not list throw error
                    throw new ConstraintViolationException(errors);
                }
            }
        }
        return pjp.proceed();
    }

    /**
     * Gets the method parameters.
     *
     * @param methodSignature the method signature
     * @return the method parameters
     */
    private static List<MethodParameter> getMethodParameters(MethodSignature methodSignature) {
        return IntStream.range(0, methodSignature.getParameterNames().length).mapToObj(i -> new MethodParameter(methodSignature.getMethod(), i))
                .collect(Collectors.toList());
    }
}