package com.ayuv.sec.auth.service.impl;

import static java.util.Collections.emptyList;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.util.StringUtils;

import com.ayuv.sec.api.auth.dto.AuthUserDto;
import com.ayuv.sec.api.auth.dto.UserLoginDto;
import com.ayuv.sec.api.auth.utils.AuthConstants;
import com.ayuv.sec.api.auth.utils.TokenBuilder;
import com.ayuv.sec.api.auth.utils.UserFactory;
import com.ayuv.sec.api.framework.core.enums.TokenType;
import com.ayuv.sec.api.framework.utils.JsonUtils;
import com.fasterxml.jackson.core.JsonProcessingException;

import lombok.extern.log4j.Log4j2;

/**
 * The Class TokenAuthenticator.
 * 

 * 
 */
@Log4j2
public class TokenAuthenticator {
	
	@Value("${jsonaccesstoken.expiration}")
    private static long accesstokenexpiration;
    
    /**
     * The refresh token expiration.
     */
    @Value("${jsonrefreshtoken.expiration}")
    private static long refreshtokenexpiration;

    /**
     * Creates the authentication token.
     *
     * @param user the user
     * @return the string
     * @throws JsonProcessingException the json processing exception
     */
    public static String createAuthenticationToken(UserLoginDto user, TokenType tokenType) throws JsonProcessingException {
    	String userProfile = null;
    	String authToken = null;
    	if(tokenType.equals(TokenType.ACCESS_TOKEN)) {
	        AuthUserDto userDto = UserFactory.build(user);
	        userProfile = JsonUtils.writeValueAsString(userDto);
	        authToken = TokenBuilder.createToken(userProfile,tokenType);
	        user.setId(authToken);
    	}
    	if(tokenType.equals(TokenType.REFRESH_TOKEN)) {
    		AuthUserDto userDto = UserFactory.build(user);
            userProfile = JsonUtils.writeValueAsString(userDto);
            authToken = TokenBuilder.createToken(userProfile,tokenType);
    	}
        log.debug("[createAuthenticationToken: userProfile={}]", userProfile);
        log.debug("[createAuthenticationToken: tokenType={}, authToken={}]", tokenType, authToken);
        return authToken;
    }

    /**
     * Gets the authentication.
     *
     * @param request the request
     * @return the authentication
     */
    public static Authentication getAuthentication(HttpServletRequest request) {
        AuthUserDto user = getAuthenticationUser(request);
        return user != null ? new UsernamePasswordAuthenticationToken(user.getUserId(), null, emptyList()) : null;
    }

    /**
     * Gets the user profile json data.
     *
     * @param request the request
     * @return the user profile json data
     */
    public static String getUserProfileJsonData(HttpServletRequest request) {
        String token = request.getHeader(AuthConstants.HEADER_AUTHORIZATION);
        if (StringUtils.hasText(token)) {
        	log.info(token);
            return TokenBuilder.getJsonData(token.replace(AuthConstants.TOKEN_PREFIX, ""));
        }
        return null;
    }

    /**
     * Gets the authentication user.
     *
     * @param request the request
     * @return the authentication user
     */
    public static AuthUserDto getAuthenticationUser(HttpServletRequest request) {
        AuthUserDto user = null;
        try {
            String jsonData = getUserProfileJsonData(request);
            if (StringUtils.hasText(jsonData)) {
                user = JsonUtils.readValue(jsonData, AuthUserDto.class);
            }
        } catch (IOException e) {
            log.error("[getAuthenticationUser: unable to get authenticated user, errorMessage={}]", e.getMessage());
        }
        return user;
    }

    /**
     * Gets the authentication user.
     *
     * @param token the token
     * @return the authentication user
     */
    public static AuthUserDto getAuthenticationUser(String token) {
        AuthUserDto user = null;
        try {
            if (StringUtils.hasText(token)) {
                String jsonData = TokenBuilder.getJsonData(token.replace(AuthConstants.TOKEN_PREFIX, ""));
                user = JsonUtils.readValue(jsonData, AuthUserDto.class);
            }
        } catch (IOException e) {
            log.error("[getAuthenticationUser: unable to get authenticated user, errorMessage={}]", e.getMessage());
        }
        return user;
    }

}
