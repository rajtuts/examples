package com.ayuv.sec.api.framework.logging;

import java.util.Map;

/**
 * The Interface LogContextData.
 * 

 * 
 */
public interface LogContextData {

    /**
     * To map.
     *
     * @return the map
     */
    Map<String, String> toMap();

}
