package com.ayuv.sec.api.framework.core.context;

import org.apache.logging.log4j.ThreadContext;

/**
 * The Class ContextHolder.
 * 

 * 
 */
public class ContextHolder {

    /** The Constant TRANS_ID. */
    private static final String TRANS_ID = "transId";

    /** The Constant USERNAME. */
    private static final String USERNAME = "username";

    /** The context thread local. */
    private static InheritableThreadLocal<Context> contextThreadLocal = new InheritableThreadLocal<>();

    /**
     * Sets the.
     *
     * @param context the context
     */
    public static void set(Context context) {
        contextThreadLocal.set(context);
        if (context != null) {
            ThreadContext.put(TRANS_ID, context.getTransId().toString());
            ThreadContext.put(USERNAME, context.getUsername());
        }
    }

    /**
     * Gets the or create.
     *
     * @return the or create
     */
    public static Context getOrCreate() {
        Context context = contextThreadLocal.get();
        if (context == null) {
            context = new Context();
            set(context);
        }
        return context;
    }

    /**
     * Removes the.
     */
    public static void remove() {
        contextThreadLocal.remove();
        ThreadContext.remove(TRANS_ID);
        ThreadContext.remove(USERNAME);
    }

    /**
     * Instantiates a new context holder.
     */
    private ContextHolder() {
    }
}
