package com.ayuv.sec.api.framework.utils;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;

/**
 * The Class XmlUtils.
 * 

 * 
 */
public class XmlUtils {

    /**
     * The Constant xmlContexts.
     */
    private static final Map<String, JAXBContext> xmlContexts = new ConcurrentHashMap<>();

    /**
     * Instantiates a new xml utils.
     */
    private XmlUtils() {
    }

    /**
     * Read value.
     *
     * @param <T>       the generic type
     * @param xmlString the xml
     * @param classType the class type
     * @return the t
     * @throws JAXBException      the JAXB exception
     * @throws XMLStreamException the XML stream exception
     */
    @SuppressWarnings("unchecked")
    public static <T> T readValue(String xmlString, Class<T> classType) throws JAXBException, XMLStreamException {
        Unmarshaller unmarshaller = xmlContext(classType).createUnmarshaller();
        XMLInputFactory xmlInputFactory = XMLInputFactory.newFactory();
        xmlInputFactory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
        xmlInputFactory.setProperty(XMLInputFactory.SUPPORT_DTD, false);
        return (T) unmarshaller.unmarshal(xmlInputFactory.createXMLStreamReader(new StringReader(xmlString)));
    }

    /**
     * Write value.
     *
     * @param xmlObj the obj
     * @return the string
     * @throws JAXBException the JAXB exception
     */
    public static String writeValue(Object xmlObj) throws JAXBException {
        if (xmlObj instanceof String) {
            return String.valueOf(xmlObj);
        } else {
            StringWriter sw = new StringWriter();
            Marshaller marshaller = xmlContext(xmlObj.getClass()).createMarshaller();
            marshaller.marshal(xmlObj, sw);
            return sw.toString();
        }
    }

    /**
     * Xml Context.
     *
     * @param cls the class
     * @return the JAXBContext
     * @throws JAXBException the JAXB exception
     */
    private static JAXBContext xmlContext(Class<?> cls) throws JAXBException {
        if (xmlContexts.containsKey(cls.getName())) {
            return xmlContexts.get(cls.getName());
        } else {
            JAXBContext context = JAXBContext.newInstance(cls);
            xmlContexts.put(cls.getName(), context);
            return context;
        }
    }
}
