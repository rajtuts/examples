package com.ayuv.sec.api.framework.core.data.jdbc.storeproc;

import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * The Class JdbcStoreProc.
 * 

 * 
 */
@Component
public class JdbcStoreProc {

    /** The jdbc template. */
    private JdbcTemplate jdbcTemplate;

    /**
     * Instantiates a new jdbc store proc.
     *
     * @param jdbcTemplate the jdbc template
     */
    @Autowired
    public JdbcStoreProc(@Qualifier("jdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * Execute oracle cursor.
     *
     * @param <T>      the generic type
     * @param spName   the sp name
     * @param spParams the sp params
     * @param rm       the rm
     * @return the t
     */
    public <T> T executeOracleCursor(String spName, List<SqlStoreProcParameterSource> spParams, RowMapper<?> rm) {
        // this method currently support only 1 cursor, please take note, and also the
        // name no need match the store proc input name
        MapSqlParameterSource paramsValue = new MapSqlParameterSource();
        List<SqlParameter> params = new ArrayList<>();
        // assign store proc type and value
        spParams.forEach(s -> {
            params.add(new SqlParameter(s.getName(), s.getType()));
            paramsValue.addValue(s.getName(), s.getValue());
        });
        // add the cursor output
        params.add(new SqlOutParameter("output", OracleTypes.CURSOR, rm));
        // assign the sp info
        SimpleJdbcCall executor = new SimpleJdbcCall(jdbcTemplate).withProcedureName(spName).withoutProcedureColumnMetaDataAccess()
                .declareParameters(params.toArray(new SqlParameter[params.size()]));
        executor.compile();
        Map<String, Object> map = executor.execute(paramsValue);
        return (T) map.get("output");
    }
}
