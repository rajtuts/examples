package com.ayuv.sec.api.framework.core.enums;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Enum YesNoType.
 * 

 * 
 */
public enum YesNoType {

    /** The yes. */
    @JsonProperty("Y")
    YES("Y", "Yes"),

    /** The no. */
    @JsonProperty("N")
    NO("N", "No");

    /** The type. */
    private final String type;

    /** The desc. */
    private final String desc;

    /**
     * Instantiates a new yes no type.
     *
     * @param type the type
     * @param desc the desc
     */
    YesNoType(String type, String desc) {
        this.type = type;
        this.desc = desc;
    }

    /**
     * Gets the type by type.
     *
     * @param type the type
     * @return the type by type
     */
    public static YesNoType getTypeByType(String type) {
        for (YesNoType ref : YesNoType.values()) {
            if (ref.type.equals(type)) {
                return ref;
            }
        }
        return null;
    }

    /**
     * Gets the type.
     *
     * @return the type
     */
    public String getType() {
        return this.type;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return this.desc;
    }

}
