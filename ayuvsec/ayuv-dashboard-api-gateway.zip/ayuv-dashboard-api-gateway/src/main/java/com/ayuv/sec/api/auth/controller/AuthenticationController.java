package com.ayuv.sec.api.auth.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ayuv.sec.api.auth.dto.AuthRequestDto;
import com.ayuv.sec.api.auth.dto.AuthResponseDto;
import com.ayuv.sec.api.auth.service.api.AuthenticationService;

/**
 * The Class AuthenticationController.
 * 
 * 
 */
@RestController
public class AuthenticationController {

    /** The authentication service. */
    @Autowired
    private AuthenticationService authenticationService;

    /**
     * Login.
     *
     * @param loginRequest the login request
     * @return the auth response dto
     */
    @PostMapping("/api/auth")
    public AuthResponseDto login(@RequestBody AuthRequestDto loginRequest) {
        return authenticationService.login(loginRequest);
    }
    
    @PostMapping("/api/auth/refresh")
    public AuthResponseDto refreshToken(@RequestBody AuthRequestDto authRequestDto) {
        return authenticationService.refreshToken(authRequestDto);
    }

    /**
     * Logout.
     *
     * @param request    the request
     * @param userId     the user id
     * @param activityId the activity id
     */
    @GetMapping("/api/auth/logout")
    public void logout(HttpServletRequest request, @RequestParam String username) {
        authenticationService.logout(request, username);
    }
}