package com.ayuv.sec.api.framework.core.context.utils;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;

import com.ayuv.sec.api.framework.core.context.Context;
import com.ayuv.sec.api.framework.core.context.ContextHolder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import feign.RequestTemplate;
import lombok.extern.log4j.Log4j2;

/**
 * The Class ContextUtils.
 * 

 * 
 */
@Log4j2
public class ContextUtils {

    /** The Constant CONTEXT_HEADER_KEY. */
    public static final String CONTEXT_HEADER_KEY = "Context";

    /** The Constant INIT_CONTEXT_USERNAME. */
    private static final String INIT_CONTEXT_USERNAME = "Initializer";

    /** The mapper. */
    private static ObjectMapper mapper = new ObjectMapper();

    /**
     * Instantiates a new context utils.
     */
    private ContextUtils() {
        throw new IllegalStateException("Utility class");
    }

    /**
     * Sets the to header.
     *
     * @param template the template
     * @param context  the context
     * @return the request template
     */
    public static RequestTemplate setToHeader(RequestTemplate template, Context context) {
        String contextString = convertToString(context);
        log.debug("Setting Context: {}", contextString);
        return template.header(CONTEXT_HEADER_KEY, contextString);
    }

    /**
     * Gets the from header.
     *
     * @param request the request
     * @return the from header
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static Context getFromHeader(HttpServletRequest request) throws IOException {
        String contextString = request.getHeader(CONTEXT_HEADER_KEY);
        if (StringUtils.isNotEmpty(contextString)) {
            log.debug("Context found: {}", contextString);
            return mapper.readValue(contextString, Context.class);
        } else {
            log.warn("No Context found in request header by key {}.", CONTEXT_HEADER_KEY);
            return null;
        }
    }

    /**
     * Convert to context.
     *
     * @param contextString the context string
     * @return the context
     */
    public static Context convertToContext(String contextString) {
        try {
            return mapper.readValue(contextString, Context.class);
        } catch (IOException e) {
            // Should not happen.
            throw new IllegalStateException(e);
        }
    }

    /**
     * Checks if is valid context.
     *
     * @param context the context
     * @return true, if is valid context
     */
    public static boolean isValidContext(Context context) {
        return StringUtils.isNotEmpty(context.getUsername());
    }

    /**
     * Convert to string.
     *
     * @param context the context
     * @return the string
     */
    public static String convertToString(Context context) {
        try {
            return mapper.writeValueAsString(context);
        } catch (JsonProcessingException e) {
            // Should not happen.
            throw new IllegalStateException(e);
        }
    }

   

    /**
     * Creates the init context.
     *
     * @return the context
     */
    public static Context createInitContext() {
        Context context = new Context();
        context.setUsername(INIT_CONTEXT_USERNAME);
        return context;
    }

    /**
     * Gets the current user.
     *
     * @return the current user
     */
    public static String getCurrentUser() {
        return ContextHolder.getOrCreate().getUsername();
    }

}
