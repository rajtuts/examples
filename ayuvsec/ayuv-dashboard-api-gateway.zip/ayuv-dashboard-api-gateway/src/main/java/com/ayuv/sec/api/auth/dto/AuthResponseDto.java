package com.ayuv.sec.api.auth.dto;

import lombok.Builder;
import lombok.Data;

/**
 * The Class AuthResponseDto.
 * 

 * 
 */
@Data
@Builder
public class AuthResponseDto {

    /** The auth token. */
    private String accessToken;
    
    /** The refresh token. */
    private String refreshToken;

    /** The auth user dto. */
//    private AuthUserDto authUserDto;

}
