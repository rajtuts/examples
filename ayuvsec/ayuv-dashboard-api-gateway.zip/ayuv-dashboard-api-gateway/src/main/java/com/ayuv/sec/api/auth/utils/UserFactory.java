package com.ayuv.sec.api.auth.utils;

import java.util.UUID;

import com.ayuv.sec.api.auth.dto.AuthUserDto;
import com.ayuv.sec.api.auth.dto.UserLoginDto;

/**
 * A factory for creating User objects.
 * 
 * 
 */
public class UserFactory {

    /**
     * Builds the AuthUserDto from the given profile.
     *
     * @param user the profiles
     * @return the user
     */
    public static AuthUserDto build(UserLoginDto user) {
        String activityId = UUID.randomUUID().toString().replace("-", "");
        return AuthUserDto.builder().activityId(activityId).userId(user.getUserId())
                .build();
    }

   
}
