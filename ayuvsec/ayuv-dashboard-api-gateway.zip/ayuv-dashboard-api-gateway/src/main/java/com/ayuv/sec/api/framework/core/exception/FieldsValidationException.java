package com.ayuv.sec.api.framework.core.exception;

import java.util.ArrayList;
import java.util.List;

/**
 * The Class FieldsValidationException.
 * 

 * 
 */
public abstract class FieldsValidationException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /** The field list. */
    private List<String> fieldList;

    /**
     * Instantiates a new fields validation exception.
     *
     * @param msg the msg
     */
    public FieldsValidationException(String msg) {
        super(msg);
    }

    /**
     * Instantiates a new fields validation exception.
     *
     * @param msg       the msg
     * @param fieldList the field list
     */
    public FieldsValidationException(String msg, List<String> fieldList) {
        super(msg);
        if (fieldList == null) {
            this.fieldList = new ArrayList<>();
        } else {
            this.fieldList = new ArrayList<>(fieldList);
        }
    }

    /**
     * Instantiates a new fields validation exception.
     *
     * @param msg the msg
     * @param t   the t
     */
    public FieldsValidationException(String msg, Throwable t) {
        super(msg, t);
    }

    /**
     * Instantiates a new fields validation exception.
     *
     * @param msg       the msg
     * @param t         the t
     * @param fieldList the field list
     */
    public FieldsValidationException(String msg, Throwable t, List<String> fieldList) {
        super(msg, t);
        if (fieldList == null) {
            this.fieldList = new ArrayList<>();
        } else {
            this.fieldList = new ArrayList<>(fieldList);
        }
    }

    /**
     * Gets the field list.
     *
     * @return the field list
     */
    public List<String> getFieldList() {
        if (fieldList == null) {
            return new ArrayList<>();
        } else {
            return new ArrayList<>(fieldList);
        }
    }

    /**
     * Sets the field list.
     *
     * @param fieldList the new field list
     */
    public void setFieldList(List<String> fieldList) {
        if (fieldList == null) {
            this.fieldList = new ArrayList<>();
        } else {
            this.fieldList = new ArrayList<>(fieldList);
        }
    }
}
