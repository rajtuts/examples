package com.ayuv.sec.api.framework.core.enums;

/**
 * The Enum ReservationStateTypes.
 * 

 * 
 */
public enum ReservationStateTypes {

    /** The requested. */
    REQUESTED("Requested"),
    /** The confirmed. */
    CONFIRMED("Confirmed"),
    /** The cancelled. */
    CANCELLED("Cancelled"),
    /** The rejected. */
    REJECTED("Rejected"),
    /** The used. */
    USED("Used"),
    /** The completed. */
    COMPLETED("Completed"),
    /** The rejected code. */
    REJECT_CODE("Reject reason from Service Point Availability Checker"),
    /** The ar rejected code. */
    AR_REJECT_CODE("Previous reservation is released due to a change in piece EDD"),
    /** The out of order reject code. */
    OOO_REJECT_CODE("The storage location unit is out of order {0},{1}");

    /** The value. */
    private String value;

    /**
     * Instantiates a new reservation state.
     *
     * @param value the value
     */
    private ReservationStateTypes(String value) {
        this.value = value;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return this.value;
    }

}
