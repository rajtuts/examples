package com.ayuv.sec.api.framework.core.context.client;

import org.springframework.stereotype.Component;

import com.ayuv.sec.api.framework.core.context.utils.ContextUtils;
import com.ayuv.sec.api.framework.core.context.Context;
import com.ayuv.sec.api.framework.core.context.ContextHolder;

import feign.RequestInterceptor;
import feign.RequestTemplate;

/**
 * The Class FeignClientContextInterceptor.
 * 

 * 
 */
@Component
public class FeignClientContextInterceptor implements RequestInterceptor {

    @Override
    public void apply(RequestTemplate template) {
        Context context = ContextHolder.getOrCreate();
        ContextUtils.setToHeader(template, context);
    }
}
