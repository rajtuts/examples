package com.ayuv.sec.api.framework.core.exception;

/**
 * The Class BadRequestException.
 * 

 * 
 */
public class BadRequestException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /**
     * Instantiates a new bad request exception.
     *
     * @param msg the msg
     */
    public BadRequestException(String msg) {
        super(msg);
    }
}
