package com.ayuv.sec.api.framework.core.context.controller;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.ByteArrayHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.util.CollectionUtils;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.log4j.Log4j2;

/**
 * The Class ControllerContextInterceptorRegistrar.
 * 

 * 
 */
@Configuration
@Log4j2
public class ControllerContextInterceptorRegistrar implements WebMvcConfigurer {

    /** The interceptor. */
    @Autowired
    private ControllerContextInterceptor interceptor;

    /** The object mapper. */
    @Autowired
    private ObjectMapper objectMapper;

    /** The custom include path. */
    @Value("${context.interceptor.custom.include.path:}")
    private List<String> customIncludePath;

    /** The custom exclude path. */
    @Value("${context.interceptor.custom.exclude.path:}")
    private List<String> customExcludePath;

    /** The default exclude path. */
    private final List<String> defaultExcludePath = Arrays.asList("/swagger-ui.html", "/webjars/**", "/swagger-resources/**", "/v2/api-docs", "/csrf",
            "/error");

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        log.info("Registering Interceptor: {}", interceptor.getClass().getName());
        List<String> includePath = CollectionUtils.isEmpty(customIncludePath) ? Collections.emptyList() : customIncludePath;
        List<String> excludePath = CollectionUtils.isEmpty(customExcludePath) ? defaultExcludePath : customExcludePath;
        registry.addInterceptor(interceptor).addPathPatterns(includePath).excludePathPatterns(excludePath);
    }

    @Override
    public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
        converters.add(new StringHttpMessageConverter());
        converters.add(new ByteArrayHttpMessageConverter());
        converters.add(new MappingJackson2HttpMessageConverter(objectMapper));
    }

    @Override
    public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
        configurer.enable();
    }
}
