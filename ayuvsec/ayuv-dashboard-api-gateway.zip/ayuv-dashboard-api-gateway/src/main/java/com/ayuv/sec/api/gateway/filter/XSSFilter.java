package com.ayuv.sec.api.gateway.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jsoup.Jsoup;
import org.jsoup.safety.Whitelist;
import org.springframework.http.MediaType;

import com.ayuv.sec.api.gateway.wrapper.ByteArrayPrinter;
import com.ayuv.sec.api.gateway.wrapper.XSSRequestWrapper;
import com.netflix.zuul.http.HttpServletResponseWrapper;

/**
 * The Class XSSFilter.
 * 

 * 
 */
public class XSSFilter implements Filter {

    /*
     * (non-Javadoc)
     * 
     * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
     */
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    /*
     * (non-Javadoc)
     * 
     * @see javax.servlet.Filter#destroy()
     */
    @Override
    public void destroy() {
    }

    /*
     * (non-Javadoc)
     * 
     * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse,
     * javax.servlet.FilterChain)
     */
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        ByteArrayPrinter pw = new ByteArrayPrinter();
        HttpServletResponse wrappedResp = new HttpServletResponseWrapper((HttpServletResponse) response) {
            @Override
            public void setContentType(final String type) {
                super.setContentType(MediaType.APPLICATION_JSON_VALUE);
            }

            @Override
            public PrintWriter getWriter() {
                return pw.getWriter();
            }

            @Override
            public ServletOutputStream getOutputStream() throws IOException {
                ServletResponse response = this.getResponse();
                String ct = (response != null) ? response.getContentType() : null;
                if (ct != null && ct.contains("application/xhtml")) {
                    response.setContentType(ct + "," + MediaType.APPLICATION_JSON_VALUE);
                }
                return pw.getStream();
            }
        };
        chain.doFilter(new XSSRequestWrapper((HttpServletRequest) request), wrappedResp);
        byte[] bytes = pw.toByteArray();
        String safeRespBody = Jsoup.clean(new String(bytes), Whitelist.basic());
        response.getOutputStream().write(safeRespBody.getBytes());
    }

}