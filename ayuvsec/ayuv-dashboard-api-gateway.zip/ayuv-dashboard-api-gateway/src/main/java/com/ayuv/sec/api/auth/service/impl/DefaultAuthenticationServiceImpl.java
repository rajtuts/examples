package com.ayuv.sec.api.auth.service.impl;

import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.stereotype.Service;

import com.ayuv.sec.api.auth.dto.AuthRequestDto;
import com.ayuv.sec.api.auth.dto.AuthResponseDto;
import com.ayuv.sec.api.auth.dto.UserLoginDto;
import com.ayuv.sec.api.auth.service.api.AuthenticationService;
import com.ayuv.sec.api.framework.core.enums.TokenType;
import com.ayuv.sec.auth.service.impl.TokenAuthenticator;
import com.ayuv.sec.api.auth.data.dao.UserLoginDao;
import com.fasterxml.jackson.core.JsonProcessingException;

import lombok.extern.log4j.Log4j2;

/**
 * The Class DefaultAuthenticationServiceImpl.
 * 
 */
@Service
@Log4j2
public class DefaultAuthenticationServiceImpl implements AuthenticationService {

	/** The user login dao. */
	@Autowired
	private UserLoginDao userLoginDao;

	@Value("${accesstoken.expiration}")
	private long accessTokentimeout;

	@Value("${refreshtoken.expiration}")
	private long refreshTokentimeout;

	/**
	 * API Login.
	 *
	 * @param loginRequest the login request
	 * @return the response entity
	 */
	public AuthResponseDto login(AuthRequestDto loginRequest) {
		AuthResponseDto authResponse = null;
		try {
			log.info("Get user authentication via web service for {}", loginRequest.getUsername());
			UserLoginDto userLoginDto = userLoginDao.authenticateUserDetails(loginRequest.getUsername(),
					loginRequest.getPassword());

			if (userLoginDto != null) {
				authResponse = constructAuthResponse(userLoginDto);
				userLoginDao.updateUserLogin(userLoginDto);
			} else {
				log.error("User authentication failed.");
				throw new BadCredentialsException("User authentication failed");
			}
		} catch (Exception e) {
			log.error("Encounter error when performing user authentication.", e);
			throw new AuthenticationServiceException(e.getMessage(), e);
		}
		return authResponse;
	}

	/**
	 * API Logout.
	 *
	 * @param request    the request
	 * @param userId     the user id
	 * @param activityId the Activity Id to identify "session" of user
	 */
	public void logout(HttpServletRequest request, String userId) {
		log.info("Logging out from PUD Portal for user id: {}", userId);
		userLoginDao.removeInactiveLogin(userId);
		HttpSession session = request.getSession();
		session.invalidate();
	}

	/**
	 * Construct the auth response.
	 *
	 * @param user the user
	 * @return the auth response
	 */
	private AuthResponseDto constructAuthResponse(UserLoginDto user) {
		AuthResponseDto authResponse;
		try {
			String accessToken = TokenAuthenticator.createAuthenticationToken(user, TokenType.ACCESS_TOKEN);
			String refreshToken = TokenAuthenticator.createAuthenticationToken(user, TokenType.REFRESH_TOKEN);
			user.setAccessToken(accessToken);
			user.setRefreshToken(refreshToken);
			authResponse = AuthResponseDto.builder()
					.accessToken(accessToken)
					.refreshToken(refreshToken).build();
		} catch (JsonProcessingException e) {
			log.error("Encounter error when login.");
			throw new AuthenticationServiceException(e.getMessage(), e);
		}
		return authResponse;
	}

	/**
	 * Construct UserLoginDto from AuthUserDto.
	 *
	 * @param user the user
	 * @return the auth response
	 */
//	private UserLoginDto constructUserLoginDto(UserLoginDto user, AuthResponseDto authResponse) {
//		UserLoginDto userLoginDto = new UserLoginDto();
//		userLoginDto.setId(user.getActivityId());
//		userLoginDto.setUserId(user.getUserId());
//		userLoginDto.setAccessToken(authResponse.getAccessToken());
//		userLoginDto.setRefreshToken(authResponse.getRefreshToken());
////		userLoginDto.setAccessTokenExp(Instant.now());
////		userLoginDto.setRefreshTokenExp(Instant.now());
//		return userLoginDto;
//	}

	/**
	 * API to update user last active time.
	 *
	 * @param activityId the activity id
	 */
	public void updateUserLastActiveTime(String userId) {
		log.info("Update last active time for user user id: {}", userId);
		userLoginDao.updateUserLastActiveTime(userId);
	}

	/*
	 * @see
	 * com.ayuv.sec.api.auth.service.api.AuthenticationService#removeInactiveLogin()
	 */
	@Override
	public void removeInactiveLogin() {
		long timeoutInSeconds = TimeUnit.MILLISECONDS.toSeconds(accessTokentimeout);
		log.info("Removing inactive login that idle for more than {} seconds.", timeoutInSeconds);
//        int deletedCount = userLoginDao.removeInactiveLogin(timeoutInSeconds);
		log.info(" inactive login removed.");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ayuv.sec.api.auth.service.api.AuthenticationService#isUserActive(java.lang
	 * .String)
	 */
	@Override
	public boolean validateAccessToken(String userId,String token) {
		long timeoutInSeconds = TimeUnit.MILLISECONDS.toSeconds(accessTokentimeout);
		log.info("Check if user idle for more than {} seconds for activityId : {}", timeoutInSeconds, userId, token);
		boolean isUserActive = userLoginDao.validateAccessToken(userId, timeoutInSeconds, token);
		log.info("User active status is {} for activity id {}", isUserActive, userId);
		return isUserActive;
	}

	@Override
	public boolean validateRefreshToken(String userId, String refreshToken) {
		long timeoutInSeconds = TimeUnit.MILLISECONDS.toSeconds(refreshTokentimeout);
		log.info("Check if user idle for more than {} seconds for activityId : {}", timeoutInSeconds, userId);
		boolean isUserActive = userLoginDao.validateRefreshToken(userId, timeoutInSeconds, refreshToken);
		log.info("User active status is {} for activity id {}", isUserActive, userId);
		return isUserActive;
	}

	public AuthResponseDto refreshToken(AuthRequestDto authRequestDto) {
		AuthResponseDto authResponse = null;
		try {
			log.info("Get user authentication via web service for {}", authRequestDto.getUsername());
			if (validateRefreshToken(authRequestDto.getUsername(),authRequestDto.getRefreshToken())) {
				UserLoginDto userLoginDto = userLoginDao.authenticateUserDetailsbyRefreshToken(authRequestDto.getUsername());
				if (userLoginDto != null) {
					authResponse = constructAuthResponse(userLoginDto);
					userLoginDao.updateUserLogin(userLoginDto);
				} else {
					log.error("User authentication failed.");
					throw new BadCredentialsException("User authentication failed");
				}
			} else {
				log.error("User authentication failed.");
				throw new BadCredentialsException("User authentication failed");
			}
		} catch (Exception e) {
			log.error("Encounter error when performing user authentication.", e);
			throw new AuthenticationServiceException(e.getMessage(), e);
		}
		return authResponse;
	}
}
