package com.ayuv.sec.api.framework.core.config;

import java.util.List;

import javax.validation.Valid;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

/**
 * The Class ValidateListWrapper.
 * 

 * 
 */
@Data
@AllArgsConstructor
@Builder
public class ValidateListWrapper {

    @Valid
    List<Object> wrapperList;

}
