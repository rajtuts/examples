package com.ayuv.sec.api.auth.service.api;

import javax.servlet.http.HttpServletRequest;

import com.ayuv.sec.api.auth.dto.AuthRequestDto;
import com.ayuv.sec.api.auth.dto.AuthResponseDto;

/**
 * The Interface AuthenticationService.
 * 

 * 
 */
public interface AuthenticationService {

    /**
     * Login.
     *
     * @param loginRequest the login request
     * @return the auth response dto
     */
    AuthResponseDto login(AuthRequestDto loginRequest);

    /**
     * Logout.
     *
     * @param request    the request
     * @param userId     the user id
     * @param activityId the activity id
     */
    void logout(HttpServletRequest request, String userId);

    /**
     * Update user last active time.
     *
     * @param activityId the activity id
     * @param userId     the user id
     */
    void updateUserLastActiveTime(String userId);

    /**
     * Removes the inactive login.
     */
    void removeInactiveLogin();

    public boolean validateAccessToken(String userId,String accessToken);
    
    public boolean validateRefreshToken(String userId,String refreshToken);
    
    public AuthResponseDto refreshToken(AuthRequestDto authRequestDto);

}
