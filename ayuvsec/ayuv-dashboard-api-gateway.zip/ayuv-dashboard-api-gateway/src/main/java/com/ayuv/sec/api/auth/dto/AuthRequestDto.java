package com.ayuv.sec.api.auth.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * The class AuthRequestDto.
 * 

 *
 */
@Data
@EqualsAndHashCode(of = { "username", "password" })
@JsonIgnoreProperties(ignoreUnknown = true)
public class AuthRequestDto {

    /** The username. */
    private String username;

    /** The password. */
    private String password;

    private String refreshToken;
}
