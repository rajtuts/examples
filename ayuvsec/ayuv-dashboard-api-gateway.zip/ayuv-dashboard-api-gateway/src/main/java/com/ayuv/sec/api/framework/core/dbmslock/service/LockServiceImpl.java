package com.ayuv.sec.api.framework.core.dbmslock.service;

import com.ayuv.sec.api.framework.core.dbmslock.dao.LockDao;
import com.ayuv.sec.api.framework.core.exception.LockException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * The Class LockServiceImpl.
 * 

 * 
 */
@Service
public class LockServiceImpl implements LockService {

    /** The lock dao. */
    @Autowired
    LockDao lockDao;

    @Override
    public Boolean lock(String key) {
        return lockDao.lock(key).isSuccess();
    }

    @Override
    public Boolean lockThrowEx(String key, String throwMessage) throws LockException {
        Boolean ret = this.lock(key);
        if (Boolean.FALSE.equals(ret)) {
            // find the info. data from
            throw new LockException(throwMessage);
        }
        return ret;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public Boolean checkLock(String key) {
        return lock(key);
    }

    @Override
    public Boolean checkLockThrowEx(String key, String throwMessage) throws LockException {
        Boolean ret = this.checkLock(key);
        if (Boolean.FALSE.equals(ret)) {
            throw new LockException(throwMessage);
        }
        return ret;
    }

}
