package com.ayuv.sec.api.framework.gateway.util;

/**
 * The Interface ErrorAnalyzer.
 * 

 * 
 */
public interface ErrorAnalyzer {

    /**
     * Determine cause chain.
     *
     * @param throwable the throwable
     * @return the throwable[]
     */
    Throwable[] determineCauseChain(Throwable throwable);

    /**
     * Gets the first throwable of type.
     *
     * @param throwableType the throwable type
     * @param chain         the chain
     * @return the first throwable of type
     */
    Throwable getFirstThrowableOfType(Class<? extends Throwable> throwableType, Throwable[] chain);

}
