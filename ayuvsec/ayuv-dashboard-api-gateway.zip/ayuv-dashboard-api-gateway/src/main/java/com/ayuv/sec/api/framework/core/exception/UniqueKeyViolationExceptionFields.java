package com.ayuv.sec.api.framework.core.exception;

import java.util.List;

/**
 * The Class UniqueKeyViolationExceptionFields.
 */
public class UniqueKeyViolationExceptionFields extends FieldsValidationException {

    private static final long serialVersionUID = 1L;

    /**
     * Instantiates a new unique key violation exception fields.
     *
     * @param msg the msg
     */
    public UniqueKeyViolationExceptionFields(String msg) {
        super(msg);
    }

    /**
     * Instantiates a new unique key violation exception fields.
     *
     * @param msg the msg
     * @param t   the t
     */
    public UniqueKeyViolationExceptionFields(String msg, Throwable t) {
        super(msg, t);
    }

    /**
     * Instantiates a new unique key violation exception fields.
     *
     * @param msg       the msg
     * @param fieldList the field list
     */
    public UniqueKeyViolationExceptionFields(String msg, List<String> fieldList) {
        super(msg, fieldList);
    }

    /**
     * Instantiates a new unique key violation exception fields.
     *
     * @param msg       the msg
     * @param t         the t
     * @param fieldList the field list
     */
    public UniqueKeyViolationExceptionFields(String msg, Throwable t, List<String> fieldList) {
        super(msg, t, fieldList);
    }
}
