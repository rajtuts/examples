package com.ayuv.sec.api.framework.core.context.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import com.ayuv.sec.api.framework.core.context.Context;
import com.ayuv.sec.api.framework.core.context.ContextHolder;
import com.ayuv.sec.api.framework.core.context.utils.ContextUtils;
import com.ayuv.sec.api.framework.core.exception.InvalidContextException;
import com.ayuv.sec.api.framework.core.exception.MissingContextException;

import lombok.extern.log4j.Log4j2;

/**
 * The Class ControllerContextInterceptor.
 * 

 * 
 */
@Component
@Log4j2
public class ControllerContextInterceptor implements HandlerInterceptor {

    /** The developer mode. */
    @Value("${ayuv.context.interceptor.developer-mode:false}")
    private boolean developerMode = false;

    /** The developer context. */
    private Context developerContext;

    /**
     * Inits the developer context.
     *
     * @param developerContext the developer context
     */
    @Autowired
    public void initDeveloperContext(@Value("${ayuv.context.interceptor.developer-context:#{null}}") String developerContext) {
        if (StringUtils.isBlank(developerContext)) {
            developerContext = "{\"username\":\"developer\"}";
        }
        this.developerContext = ContextUtils.convertToContext(developerContext);
    }

    /**
     * Should by pass.
     *
     * @return true, if successful
     */
    private boolean shouldByPass() {
        log.warn("Context is invalid, bypass if in developer mode. Bypass:" + developerMode);
        return developerMode;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        Context context;
        try {
            context = ContextUtils.getFromHeader(request);
        } catch (IOException e) {
            throw new InvalidContextException(e.getMessage(), e);
        }
        if (context != null) {
            if (ContextUtils.isValidContext(context) || shouldByPass()) {
                ContextHolder.set(context);
            } else {
                log.error("Throwing exception due to Context is invalid! contextString={}", ContextUtils.convertToString(context));
                throw new InvalidContextException("Context is invalid!");
            }
        } else if (developerMode) {
            context = new Context(developerContext);
            log.warn("In developer mode. Adding new context. contextString={}", ContextUtils.convertToString(context));
            ContextHolder.set(context);
        } else {
            log.error("Throwing exception due to not in developer mode and missing Context.");
            throw new MissingContextException("Missing Context.");
        }
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        ContextHolder.remove();
    }

}
