package com.ayuv.sec.api.gateway.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.Instant;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.GenericFilterBean;

import com.ayuv.sec.api.auth.dto.AuthUserDto;
import com.ayuv.sec.api.auth.service.api.AuthenticationService;
import com.ayuv.sec.api.auth.utils.AuthConstants;
import com.ayuv.sec.api.auth.utils.BasicAuthenticationUtil;
import com.ayuv.sec.api.framework.core.context.Context;
import com.ayuv.sec.api.framework.core.context.ContextHolder;
import com.ayuv.sec.api.framework.core.exception.ErrorInfo;
import com.ayuv.sec.api.framework.core.utils.ErrorConstants;
import com.ayuv.sec.api.framework.utils.JsonUtils;
import com.ayuv.sec.auth.service.impl.TokenAuthenticator;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.UnsupportedJwtException;
import lombok.extern.log4j.Log4j2;

/**
 * The Class AuthenticationFilter.
 * 

 * 
 */
@Log4j2
public class AuthenticationFilter extends GenericFilterBean {

    /** The access key. */
    @Value("${api.access.key}")
    private String accessKey;

    /** The access value. */
    @Value("${api.access.value}")
    private String accessValue;

    /** The authentication service. */
    @Autowired
    private AuthenticationService authenticationService;

    /** The Constant BASCI_AUTH. */
    public static final String BASCI_AUTH = "BASICAUTH";

    /** The Constant ACTUATOR_URL_WHITE_LIST_PATTERN. */
    private static final String ACTUATOR_URL_WHITE_LIST_PATTERN = "^/actuator/.*";

    /** The Constant ACTUATOR_URL_WHITE_LIST. */
    private static final Pattern ACTUATOR_URL_WHITE_LIST = Pattern.compile(ACTUATOR_URL_WHITE_LIST_PATTERN);

    /** The Constant URL_WHITE_LIST. */
    private static final Pattern URL_WHITE_LIST = Pattern.compile("^/api/auth|^/api/auth/.*|" + ACTUATOR_URL_WHITE_LIST_PATTERN
            + "|^/.*\\.js|^/.*\\.ico|^/.*\\.css|^/assets/.*|^/build/.*|^/config/.*|^.*/ws.*");

    /*
     * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse,
     * javax.servlet.FilterChain)
     */
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
            throws IOException, ServletException {
        try {
            HeaderMapRequestWrapper requestWrapper = new HeaderMapRequestWrapper((HttpServletRequest) servletRequest);
            String url = requestWrapper.getPathInfo();

            if (URL_WHITE_LIST.matcher(url).matches()) {
                if (ACTUATOR_URL_WHITE_LIST.matcher(url).matches()) {
                    log.trace("[doFilter-actuator: whitelisted-request, url={}]", url);
                } else {
                    log.info("[doFilter: whitelisted-request, url={}]", url);
                }
            } else {
                Authentication authentication;
                AuthUserDto user;
                String token = requestWrapper.getHeader(AuthConstants.HEADER_AUTHORIZATION);
                token = token.replace(AuthConstants.TOKEN_PREFIX, "").trim();
                log.info(token);
                try {
                    authentication = TokenAuthenticator.getAuthentication(requestWrapper);
                    user = TokenAuthenticator.getAuthenticationUser(requestWrapper);
                } catch (ExpiredJwtException ex) {
                    log.info("Token validity expired, checking if user idle for too long..");
                    throw ex;
                }
                SecurityContextHolder.getContext().setAuthentication(authentication);
                if (user != null) {
                	if(authenticationService.validateAccessToken(user.getUserId(),token)) {
	                    requestWrapper.addHeader(BASCI_AUTH, BasicAuthenticationUtil.generateBasicAutenticationHeader(accessKey, accessValue));
	                    authenticationService.updateUserLastActiveTime(user.getUserId());
	                    log.info("[doFilter: authenticated-request, url={}]", url);
                	} else {
                		log.error("Token validity expired, checking if user idle for too long..");
                        throw new BadCredentialsException("Token validity expired, checking if user idle for too long..");
                	}
                } else {
            		log.error("Token validity expired, checking if user idle for too long..");
                    throw new BadCredentialsException("Token validity expired, checking if user idle for too long..");
            	}
                
            }
            filterChain.doFilter(requestWrapper, (HttpServletResponse) servletResponse);
        } catch (ExpiredJwtException | UnsupportedJwtException | MalformedJwtException | SignatureException ex) {
            log.error("[doFilter: Token is expired or invalid, errorMessage={}]", ex.getMessage());
            Context context = ContextHolder.getOrCreate();
            ErrorInfo errorInfo = new ErrorInfo(context.getTransId().toString(), Instant.now(), ErrorConstants.AUTHENTICATION_ERR_CODE,
                    ex.getMessage());
            constructResponse((HttpServletResponse) servletResponse, HttpStatus.UNAUTHORIZED, errorInfo);
        }
    }

    /**
     * Construct the response.
     *
     * @param response   the response
     * @param httpStatus the http status
     * @param errorInfo  the errorInfo
     * @throws IOException Signals that an I/O exception has occurred.
     */
    private void constructResponse(HttpServletResponse response, HttpStatus httpStatus, ErrorInfo errorInfo) throws IOException {
        PrintWriter out = response.getWriter();
        response.setStatus(httpStatus.value());
        response.setContentType(AuthConstants.CONTENT_TYPE_JSON);
        response.setCharacterEncoding(AuthConstants.CHARACTER_ENCODING_UTF8);
        out.print(JsonUtils.writeValueAsString(errorInfo));
        out.flush();
        if (out != null) {
            out.close();
        }
    }

    /**
     * Allow adding additional header entries to a request.
     */
    public class HeaderMapRequestWrapper extends HttpServletRequestWrapper {
        /**
         * Construct a wrapper for this request
         *
         * @param request the HttpServletRequest
         */
        public HeaderMapRequestWrapper(HttpServletRequest request) {
            super(request);
        }

        private Map<String, String> headerMap = new HashMap<>();

        /**
         * Add a header with given name and value
         *
         * @param name  header key
         * @param value header value
         */
        public void addHeader(String name, String value) {
            headerMap.put(name, value);
        }

        /**
         * Gets the header.
         *
         * @param name the name
         * @return the header
         */
        @Override
        public String getHeader(String name) {
            String headerValue = super.getHeader(name);
            if (headerMap.containsKey(name)) {
                headerValue = headerMap.get(name);
            }
            return headerValue;
        }

        /**
         * Gets the Header names.
         *
         * @return the header names
         */
        @Override
        public Enumeration<String> getHeaderNames() {
            List<String> names = Collections.list(super.getHeaderNames());
            names.addAll(headerMap.keySet());
            return Collections.enumeration(names);
        }

        /**
         * Gets the headers.
         *
         * @param name the name
         * @return the headers
         */
        @Override
        public Enumeration<String> getHeaders(String name) {
            List<String> values = Collections.list(super.getHeaders(name));
            if (headerMap.containsKey(name)) {
                values.add(headerMap.get(name));
            }
            return Collections.enumeration(values);
        }
    }
}
