package com.ayuv.sec.api.auth.data.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.ayuv.sec.api.auth.data.sql.UserLoginSQL;
import com.ayuv.sec.api.auth.dto.UserLoginDto;

/**
 * The Class UserLoginDaoImpl.
 * 
 * 
 */
@Repository
public class UserLoginDaoImpl implements UserLoginDao {

	/** The jdbc template. */
	@Autowired
	@Qualifier("jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
    
	@Override
	public void updateUserLastActiveTime(String userId) {
		jdbcTemplate.update(con -> {
			PreparedStatement ps = con.prepareStatement(UserLoginSQL.UPDATE_USER_LAST_ACTIVITY_TIME);
			ps.setString(1, userId);
			return ps;
		});
	}

	@Override
	public void removeInactiveLogin(String userId) {
		jdbcTemplate.update(con -> {
			PreparedStatement ps = con.prepareStatement(UserLoginSQL.DELETE_INACTIVE_USER_DETAILS);
			ps.setString(1, userId);
			return ps;
		});
	}

	@Override
	public void updateUserLogin(UserLoginDto userLoginDto) {

		jdbcTemplate.update(con -> {
			PreparedStatement ps = con.prepareStatement(UserLoginSQL.UPDATE_USER);
			ps.setString(1, userLoginDto.getAccessToken());
			ps.setString(2, userLoginDto.getRefreshToken());
			ps.setString(3, userLoginDto.getUserId());
			return ps;
		});
	}

	@Override
	public UserLoginDto authenticateUserDetails(String username, String password) {
		UserLoginDto userLoginDto = null;
		List<UserLoginDto> lstUserLoginDto = jdbcTemplate.query(UserLoginSQL.GET_ACTIVE_USER_DETAILS,
				new UserLoginDtoRowMapper(), new Object[] { username, password });
		if (CollectionUtils.isNotEmpty(lstUserLoginDto)) {
			userLoginDto = lstUserLoginDto.get(0);
		}
		return userLoginDto;
	}
	
	@Override
	public UserLoginDto authenticateUserDetailsbyRefreshToken(String username) {
		UserLoginDto userLoginDto = null;
		List<UserLoginDto> lstUserLoginDto = jdbcTemplate.query(UserLoginSQL.GET_ACTIVE_USER_DETAILS_BY_REFRESHTOKEN,
				new UserLoginDtoRowMapper(), new Object[] { username });
		if (CollectionUtils.isNotEmpty(lstUserLoginDto)) {
			userLoginDto = lstUserLoginDto.get(0);
		}
		return userLoginDto;
	}

	@Override
	public boolean validateAccessToken(String userId, long timeoutInSeconds,String token) {
		List<Map<String, Object>> rows = jdbcTemplate.queryForList(UserLoginSQL.VALIDATE_ACCESSTOKEN,
				new Object[] { userId, token, timeoutInSeconds });
		if (!CollectionUtils.isEmpty(rows)) {
			String user = (String) (rows.get(0).get("USER_ID"));
			if (StringUtils.equals(userId, user)) {
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

	@Override
	public boolean validateRefreshToken(String userId, long timeoutInSeconds,String token) {

		List<Map<String, Object>> rows = jdbcTemplate.queryForList(UserLoginSQL.VALIDATE_REFRESHTOKEN,
				new Object[] { userId, token, timeoutInSeconds });
		if (!CollectionUtils.isEmpty(rows)) {
			String user = (String) (rows.get(0).get("USER_ID"));
			if (StringUtils.equals(userId, user)) {
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

}

class UserLoginDtoRowMapper implements RowMapper<UserLoginDto> {

	@Override
	public UserLoginDto mapRow(ResultSet rs, int rowNum) throws SQLException {
		UserLoginDto userLoginDto = new UserLoginDto();
		userLoginDto.setUserId(rs.getString("USER_ID"));
		userLoginDto.setPassword(rs.getString("PASSWORD"));
		userLoginDto.setRefreshToken(rs.getString("REFRESH_TOKEN"));
		userLoginDto.setAccessToken(rs.getString("ACCESS_TOKEN"));
		return userLoginDto;
	}

}