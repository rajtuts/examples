package com.ayuv.sec.api.gateway.wrapper;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.servlet.ServletOutputStream;
import javax.servlet.WriteListener;

/**
 * The Class ByteArrayServletStream.
 * 

 * 
 */
public class ByteArrayServletStream extends ServletOutputStream {

    /** The baos. */
    private ByteArrayOutputStream baos;

    public ByteArrayServletStream(ByteArrayOutputStream baos) {
        this.baos = baos;
    }

    @Override
    public void write(int param) throws IOException {
        baos.write(param);
    }

    @Override
    public boolean isReady() {
        return false;
    }

    @Override
    public void setWriteListener(WriteListener listener) {

    }

}