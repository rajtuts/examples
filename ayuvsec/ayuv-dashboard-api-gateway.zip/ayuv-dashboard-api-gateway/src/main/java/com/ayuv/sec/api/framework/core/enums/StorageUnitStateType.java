package com.ayuv.sec.api.framework.core.enums;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Enum StorageUnitStateType.
 * 

 * 
 */
public enum StorageUnitStateType {

    @JsonProperty("Completed")
    COMPLETED("Completed", "completed"),

    @JsonProperty("Confirmed")
    CONFIRMED("Confirmed", "confirmed"),

    @JsonProperty("In Reservation")
    IN_RESERVATION("In Reservation", "reserved"),

    @JsonProperty("Occupied")
    OCCUPIED("Occupied", "occupied"),

    @JsonProperty("Occupied (3P)")
    OCCUPIED3P("Occupied (3P)", "occupied3P"),

    @JsonProperty("Out of Order")
    OUT_OF_ORDER("Out of Order", "out-of-order"),

    @JsonProperty("Used")
    USED("Used", "occupied");

    /** The state. */
    private final String state;

    /** The cssClass. */
    private final String cssClass;

    /**
     * Instantiates a new active deactive state.
     *
     * @param state    the state
     * @param cssClass the css class
     */
    StorageUnitStateType(String state, String cssClass) {
        this.state = state;
        this.cssClass = cssClass;
    }

    /**
     * Gets the StorageUnitStateType by state.
     *
     * @param state the state
     * @return the state by state
     */
    public static StorageUnitStateType getTypeByType(String state) {
        for (StorageUnitStateType cssClass : StorageUnitStateType.values()) {
            if (cssClass.state.equals(state)) {
                return cssClass;
            }
        }
        return null;
    }

    /**
     * Gets the state.
     *
     * @return the state
     */
    public String getState() {
        return this.state;
    }

    /**
     * Gets the css class.
     *
     * @return the css class
     */
    public String getCssClass() {
        return this.cssClass;
    }

}