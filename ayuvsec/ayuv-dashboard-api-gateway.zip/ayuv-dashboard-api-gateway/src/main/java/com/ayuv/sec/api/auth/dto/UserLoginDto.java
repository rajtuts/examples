package com.ayuv.sec.api.auth.dto;

import java.time.Instant;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserLoginDto.
 * 
 */
@Data
@NoArgsConstructor
public class UserLoginDto {

    /** The activity id. */
    private String id;

    /** The user id. */
    private String userId;

    private String password;
    
    private String refreshToken;
    
    private String accessToken;
    
    private Instant accessTokenExp;
    
    private Instant refreshTokenExp;

}
