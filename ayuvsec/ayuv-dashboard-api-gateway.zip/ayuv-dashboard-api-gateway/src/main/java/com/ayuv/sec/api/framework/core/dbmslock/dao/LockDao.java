package com.ayuv.sec.api.framework.core.dbmslock.dao;

import com.ayuv.sec.api.framework.core.dbmslock.LockStatus;

/**
 * The Interface LockDao.
 * 

 * 
 */
public interface LockDao {

    /**
     * Lock.
     *
     * @param key the key
     * @return the lock status
     */
    public LockStatus lock(String key);

}
