package com.ayuv.sec.api.framework.core.exception;

import org.springframework.security.core.AuthenticationException;

/**
 * The Class InvalidContextException.
 * 

 * 
 */
public class InvalidContextException extends AuthenticationException {

    private static final long serialVersionUID = 1L;

    /**
     * Instantiates a new invalid context exception.
     *
     * @param msg the msg
     */
    public InvalidContextException(String msg) {
        super(msg);
    }

    /**
     * Instantiates a new invalid context exception.
     *
     * @param msg the msg
     * @param t   the t
     */
    public InvalidContextException(String msg, Throwable t) {
        super(msg, t);
    }

}
