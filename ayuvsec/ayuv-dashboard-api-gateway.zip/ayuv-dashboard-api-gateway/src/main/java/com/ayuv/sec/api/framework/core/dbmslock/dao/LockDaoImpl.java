package com.ayuv.sec.api.framework.core.dbmslock.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Repository;

import com.ayuv.sec.api.framework.core.dbmslock.LockStatus;

import java.sql.CallableStatement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * The Class LockDaoImpl.
 * 

 * 
 */
@Repository
public class LockDaoImpl implements LockDao {

    /** The jdbc template. */
    @Autowired
    @Qualifier("jdbcTemplate")
    private JdbcTemplate jdbcTemplate;

    /**
     * Lock.
     *
     * @param key the key
     * @return the lock status
     */
    @Override
    public LockStatus lock(String key) {
        List<SqlParameter> prmtrsList = new ArrayList<>();
        prmtrsList.add(new SqlParameter(Types.VARCHAR));
        prmtrsList.add(new SqlOutParameter("output", Types.INTEGER));

        Map<String, Object> resultData = jdbcTemplate.call(connection -> {
            CallableStatement callableStatement = connection.prepareCall("{call sp_lock(?, ?)}");
            callableStatement.setString(1, key);
            callableStatement.registerOutParameter(2, Types.INTEGER);
            return callableStatement;
        }, prmtrsList);
        return LockStatus.getStatusByValue(Long.parseLong(resultData.get("output").toString()));
    }

}
