package com.ayuv.sec.api.framework.core.data.jdbc.storeproc;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

/**
 * The Class SqlStoreProcParameterSource.
 * 

 * 
 */
@AllArgsConstructor
@Data
@Builder
@ToString
public class SqlStoreProcParameterSource {

    /** The name. */
    private String name;

    /** The type. */
    private Integer type;

    /** The value. */
    private Object value;

}
