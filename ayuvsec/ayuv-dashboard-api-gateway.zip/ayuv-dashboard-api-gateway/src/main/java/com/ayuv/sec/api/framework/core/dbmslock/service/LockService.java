package com.ayuv.sec.api.framework.core.dbmslock.service;

import com.ayuv.sec.api.framework.core.exception.LockException;

/**
 * The Interface LockService.
 * 

 * 
 */
public interface LockService {

    /**
     * Lock.
     *
     * @param key the key
     * @return the boolean
     */
    public Boolean lock(String key);

    /**
     * Lock throw ex.
     *
     * @param key          the key
     * @param throwMessage the throw message
     * @return the boolean
     * @throws LockException the lock exception
     */
    public Boolean lockThrowEx(String key, String throwMessage) throws LockException;

    /**
     * Check lock.
     *
     * @param key the key
     * @return the boolean
     */
    public Boolean checkLock(String key);

    /**
     * Check lock throw ex.
     *
     * @param key          the key
     * @param throwMessage the throw message
     * @return the boolean
     * @throws LockException the lock exception
     */
    public Boolean checkLockThrowEx(String key, String throwMessage) throws LockException;

}
