package com.ayuv.sec.api.framework.core.data.jdbc;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.UncategorizedSQLException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.support.KeyHolder;

import com.ayuv.sec.api.framework.core.utils.ErrorConstants;

import lombok.extern.log4j.Log4j2;

/**
 * The Class JdbcTemplateExt.
 * 

 * 
 */
@Log4j2
public class JdbcTemplateExt extends JdbcTemplate {

    /** The try count. */
    @Value("${spring.data.retry.limit:" + ErrorConstants.RETRY_LIMIT + "}")
    private int tryCount;

    /** The retry sleep duration. */
    @Value("${spring.data.retry.interval:" + ErrorConstants.RETRY_INTERVAL + "}")
    private long retrySleepDuration;

    /**
     * Instantiates a new jdbc template ext.
     */
    public JdbcTemplateExt() {
        super();
    }

    /**
     * Instantiates a new jdbc template ext.
     *
     * @param dataSource the data source
     */
    public JdbcTemplateExt(DataSource dataSource) {
        super(dataSource);

    }

    /**
     * Instantiates a new jdbc template ext.
     *
     * @param dataSource the data source
     * @param lazyInit   the lazy init
     */
    public JdbcTemplateExt(DataSource dataSource, boolean lazyInit) {
        super(dataSource, lazyInit);
    }

    @Override
    public <T> T query(PreparedStatementCreator psc, final PreparedStatementSetter pss, final ResultSetExtractor<T> rse) {
        for (int i = 0; i <= tryCount; i++) {
            try {
                return super.query(psc, pss, rse);
            } catch (UncategorizedSQLException e) {
                handleError(tryCount, i, e);
            }
        }
        return null;
    }

    @Override
    protected int update(final PreparedStatementCreator psc, final PreparedStatementSetter pss) {
        for (int i = 0; i <= tryCount; i++) {
            try {
                return super.update(psc, pss);
            } catch (UncategorizedSQLException e) {
                handleError(tryCount, i, e);
            }
        }
        return 0;
    }

    @Override
    public int update(final PreparedStatementCreator psc, final KeyHolder generatedKeyHolder) {
        for (int i = 0; i <= tryCount; i++) {
            try {
                return super.update(psc, generatedKeyHolder);
            } catch (UncategorizedSQLException e) {
                handleError(tryCount, i, e);
            }
        }
        return 0;
    }

    @Override
    public int[] batchUpdate(String sql, final BatchPreparedStatementSetter pss) {
        for (int i = 0; i <= tryCount; i++) {
            try {
                return super.batchUpdate(sql, pss);
            } catch (UncategorizedSQLException e) {
                handleError(tryCount, i, e);
            }
        }
        return new int[0];
    }

    /**
     * Handle error.
     *
     * @param retryCount the retry count
     * @param i          the i
     * @param e          the e
     */
    private void handleError(int retryCount, int i, UncategorizedSQLException e) {
        int errorCode = e.getSQLException().getErrorCode();
        log.warn("SQL Exception error code = {}", errorCode);
        if (ErrorConstants.INT_ORA_08103 == errorCode || ErrorConstants.INT_ORA_08005 == errorCode) {
            log.warn("ORA-0{} occurred for retry count={} with sql - {}", errorCode, i, e.getSql());
            if (i >= retryCount) {
                log.error("ORA-0{} retry exceeded the limit. Throwing exception to the caller. {}", errorCode, e.getSql());
                throw e;
            }
            try {
                Thread.sleep(retrySleepDuration);
            } catch (InterruptedException ie) {
                log.warn("Should not be interrupted.", ie);
                Thread.currentThread().interrupt();
            }
        } else {
            throw e;
        }
    }

}
