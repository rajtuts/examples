package com.ayuv.sec.api.framework.core.client;

import feign.Response;
import feign.codec.ErrorDecoder;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

/**
 * The Class FeignClientErrorDecoder.
 * 

 * 
 */
@Component
public class FeignClientErrorDecoder implements ErrorDecoder {

    @Override
    public Exception decode(String methodKey, Response response) {
        return new ResponseStatusException(HttpStatus.resolve(response.status()), response.reason());
    }

}
