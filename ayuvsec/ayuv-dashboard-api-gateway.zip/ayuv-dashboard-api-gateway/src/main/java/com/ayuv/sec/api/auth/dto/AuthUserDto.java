package com.ayuv.sec.api.auth.dto;

import java.time.Instant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserLoginDto.
 * 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuthUserDto {
	
    /** The activity id. */
    private String activityId;
    
    /** The activity id. */
    private String refreshId;

    /** The user id. */
    private String userId;

    private String password;
    
    /** The created by. */
    private String createdBy;

    /** The updated by. */
    private String updatedBy;

    /** The created dtm. */
    private Instant createdDtm;

    /** The updated dtm. */
    private Instant updatedDtm;
    
    private String refreshToken;
    
    private String accessToken;
    
    private Instant accessTokenExp;
    
    private Instant refreshTokenExp;
    
}
