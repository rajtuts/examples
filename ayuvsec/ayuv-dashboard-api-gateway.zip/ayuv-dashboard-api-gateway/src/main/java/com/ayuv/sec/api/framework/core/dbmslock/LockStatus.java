package com.ayuv.sec.api.framework.core.dbmslock;

/**
 * The Enum LockStatus.
 * 

 * 
 */
public enum LockStatus {

    /** The success. */
    SUCCESS(0L, "Success"),
    /** The timeout. */
    TIMEOUT(1L, "Timeout"),
    /** The deadlock. */
    DEADLOCK(2L, "Deadlock"),
    /** The parameter error. */
    PARAMETER_ERROR(3L, "Parameter error"),
    /** The already owned. */
    ALREADY_OWNED(4L, "Already owned"),
    /** The illegal lock handle. */
    ILLEGAL_LOCK_HANDLE(5L, "Illegal lock handle");

    /** The value. */
    private final Long value;

    /** The desc. */
    private final String desc;

    /**
     * Instantiates a new lock status.
     *
     * @param value the value
     * @param desc  the desc
     */
    LockStatus(long value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    /**
     * Gets the status by value.
     *
     * @param value the value
     * @return the status by value
     */
    public static LockStatus getStatusByValue(Long value) {
        for (LockStatus type : LockStatus.values()) {
            if (type.value.equals(value)) {
                return type;
            }
        }
        return null;
    }

    /**
     * Checks if is success.
     *
     * @return the boolean
     */
    public Boolean isSuccess() {
        return this.value == 0;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public Long getValue() {
        return this.value;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return this.desc;
    }
}
