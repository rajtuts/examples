package com.ayuv.sec.api.auth.utils;

/**
 * The Class AuthConstants.
 * 

 * 
 */
public class AuthConstants {

    /**
     * The Constant CONTENT_TYPE_JSON.
     */
    public static final String CONTENT_TYPE_JSON = "application/json";

    /**
     * The Constant CHARACTER_ENCODING_UTF8.
     */
    public static final String CHARACTER_ENCODING_UTF8 = "UTF-8";

   /**
     * The Constant HEADER_AUTHORIZATION.
     */
    public static final String HEADER_AUTHORIZATION = "Authorization";

    /**
     * The Constant TOKEN_FORMAT.
     */
    public static final String TOKEN_FORMAT = "%s %s";

    /**
     * The Constant TOKEN_PREFIX.
     */
    public static final String TOKEN_PREFIX = "Bearer";
    
    /**
    * The Constant TOKEN_PREFIX.
    */
    public static final String TOKEN_ACCESS = "access_token";
    
    /**
     */
    public static final String TOKEN_REFRESH = "refresh_token";

}
