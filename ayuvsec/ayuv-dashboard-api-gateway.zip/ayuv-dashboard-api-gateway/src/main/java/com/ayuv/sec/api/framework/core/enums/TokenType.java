package com.ayuv.sec.api.framework.core.enums;

public enum TokenType {
	
	ACCESS_TOKEN {
		public String toString() {
			return "ACCESS_TOKEN";
		}
	},
	REFRESH_TOKEN {
		public String toString() {
			return "REFRESH_TOKEN";
		}
	}

}
