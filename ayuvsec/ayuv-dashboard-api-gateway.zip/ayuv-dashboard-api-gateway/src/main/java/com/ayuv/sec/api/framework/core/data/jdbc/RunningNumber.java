package com.ayuv.sec.api.framework.core.data.jdbc;

import lombok.Builder;

/**
 * The Class RunningNumber.
 * 

 * 
 */
@Builder
public class RunningNumber {

    /** The running no. */
    @Builder.Default
    private int runningNo = 0;

    /**
     * Gets the next running no.
     *
     * @return the next running no
     */
    public int getNextRunningNo() {
        this.runningNo += 1;
        return runningNo;
    }

    /**
     * Reset running no.
     */
    public void resetRunningNo() {
        runningNo = 0;
    }
}
