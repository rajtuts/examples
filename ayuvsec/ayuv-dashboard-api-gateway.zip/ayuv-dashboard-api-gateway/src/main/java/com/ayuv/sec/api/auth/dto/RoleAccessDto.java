package com.ayuv.sec.api.auth.dto;

import java.util.HashSet;
import java.util.Set;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RoleAccessDto.
 * 

 * 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoleAccessDto {

    /** The flag to indicate global access. */
    private boolean isGlobal;
    
    /** The is admin. */
    private boolean isAdmin;

    /** The countries. */
    private Set<String> countries = new HashSet<>();

    /** The service areas. */
    private Set<String> serviceAreas = new HashSet<>();

    /** The facilities. */
    private Set<String> facilities = new HashSet<>();

}
