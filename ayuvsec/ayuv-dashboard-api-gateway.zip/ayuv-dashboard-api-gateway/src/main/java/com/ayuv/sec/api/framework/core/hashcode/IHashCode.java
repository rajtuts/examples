package com.ayuv.sec.api.framework.core.hashcode;

/**
 * The Interface IHashCode.
 * 

 * 
 */
public interface IHashCode {

    /**
     * Gets the hash.
     *
     * @param includeMinorChange the include minor change
     * @return the hash
     */
    int getHash(Boolean includeMinorChange);
}
