package com.ayuv.sec.api.framework.core.exception;

/**
 * The Class ReferenceVersionLimitExceededException.
 * 

 * 
 */
public class ReferenceVersionLimitExceededException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /**
     * Instantiates a new reference version limit exceeded exception.
     *
     * @param msg the msg
     */
    public ReferenceVersionLimitExceededException(String msg) {
        super(msg);
    }

    /**
     * Instantiates a new reference version limit exceeded exception.
     *
     * @param msg the msg
     * @param t   the t
     */
    public ReferenceVersionLimitExceededException(String msg, Throwable t) {
        super(msg, t);
    }
}
