package com.ayuv.sec.api.framework.core.utils;

/**
 * The Class ErrorConstants.
 * 

 * 
 */
public class ErrorConstants {

    /** The Constant INT_ORA_08103. */
    public static final int INT_ORA_08103 = 8103; // Oracle error code when purging runs, object no longer exists

    /** The Constant INT_ORA_08005. */
    public static final int INT_ORA_08005 = 8005; // Oracle error code when purging runs, specified row does not exists

    /** The Constant RETRY_LIMIT. */
    public static final int RETRY_LIMIT = 3; // Use this as the default retry limit if not found in property

    /** The Constant RETRY_INTERVAL. */
    public static final long RETRY_INTERVAL = 200; // Use this as the default retry interval in milliseconds if not found in
                                                   // database

    /** The Constant GENERAL_ERR_CODE. */
    public static final String GENERAL_ERR_CODE = "ERR-100";

    /** The Constant AUTHENTICATION_ERR_CODE. */
    public static final String AUTHENTICATION_ERR_CODE = "ERR-400";

    /** The Constant AUTHORIZATION_ERR_CODE. */
    public static final String AUTHORIZATION_ERR_CODE = "ERR-401";

    /** The Constant ILLEGAL_ARGS_ERR_CODE. */
    public static final String ILLEGAL_ARGS_ERR_CODE = "ERR-200";

    /** The Constant RESPONSE_STATUS_ERR_CODE. */
    public static final String RESPONSE_STATUS_ERR_CODE = "ERR-101";

    /** The Constant JDBC_UPDATE_INCORRECT_NUMBER_OF_ROWS_ERR_CODE. */
    public static final String JDBC_UPDATE_INCORRECT_NUMBER_OF_ROWS_ERR_CODE = "ERR-500";

    /** The Constant UNIQUE_KEY_VIOLATION_ERR_CODE. */
    public static final String UNIQUE_KEY_VIOLATION_ERR_CODE = "ERR-501";

    /** The Constant REF_VER_SIZE_LIMIT_EXCEEDED_ERR_CODE. */
    public static final String REF_VER_SIZE_LIMIT_EXCEEDED_ERR_CODE = "ERR-502";

    /** The Constant KEY_LOCKED_ERR_CODE. */
    public static final String KEY_LOCKED_ERR_CODE = "ERR-201";

    /** The Constant FIELD_VALIDATION_ERR_CODE. */
    public static final String FIELD_VALIDATION_ERR_CODE = "ERR-202";

    /** The Constant BAD_REQUEST_ERR_CODE. */
    public static final String BAD_REQUEST_ERR_CODE = "ERR-203";

    /**
     * Instantiates a new error constants.
     */
    private ErrorConstants() {
    }
}
