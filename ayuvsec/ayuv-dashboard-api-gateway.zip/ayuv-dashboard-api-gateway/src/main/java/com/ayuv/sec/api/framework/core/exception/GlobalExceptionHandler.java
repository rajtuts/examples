package com.ayuv.sec.api.framework.core.exception;

import static com.ayuv.sec.api.framework.core.utils.ErrorConstants.AUTHENTICATION_ERR_CODE;
import static com.ayuv.sec.api.framework.core.utils.ErrorConstants.AUTHORIZATION_ERR_CODE;
import static com.ayuv.sec.api.framework.core.utils.ErrorConstants.BAD_REQUEST_ERR_CODE;
import static com.ayuv.sec.api.framework.core.utils.ErrorConstants.FIELD_VALIDATION_ERR_CODE;
import static com.ayuv.sec.api.framework.core.utils.ErrorConstants.GENERAL_ERR_CODE;
import static com.ayuv.sec.api.framework.core.utils.ErrorConstants.ILLEGAL_ARGS_ERR_CODE;
import static com.ayuv.sec.api.framework.core.utils.ErrorConstants.JDBC_UPDATE_INCORRECT_NUMBER_OF_ROWS_ERR_CODE;
import static com.ayuv.sec.api.framework.core.utils.ErrorConstants.KEY_LOCKED_ERR_CODE;
import static com.ayuv.sec.api.framework.core.utils.ErrorConstants.REF_VER_SIZE_LIMIT_EXCEEDED_ERR_CODE;
import static com.ayuv.sec.api.framework.core.utils.ErrorConstants.RESPONSE_STATUS_ERR_CODE;
import static com.ayuv.sec.api.framework.core.utils.ErrorConstants.UNIQUE_KEY_VIOLATION_ERR_CODE;

import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.JdbcUpdateAffectedIncorrectNumberOfRowsException;
import org.springframework.security.access.AuthorizationServiceException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.server.ResponseStatusException;

import com.ayuv.sec.api.framework.core.context.Context;
import com.ayuv.sec.api.framework.core.context.ContextHolder;
import com.fasterxml.jackson.databind.ObjectMapper;

import feign.FeignException;
import lombok.extern.log4j.Log4j2;

/**
 * The Class GlobalExceptionHandler.
 * 

 * 
 */
@ControllerAdvice
@Log4j2
public class GlobalExceptionHandler {

    /** The object mapper. */
    ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Handle authentication exception.
     *
     * @param ex the ex
     * @return the error info
     */
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ExceptionHandler(value = AuthenticationException.class)
    @ResponseBody
    public ErrorInfo handleAuthenticationException(AuthenticationException ex) {
        return handleExceptionInternal(ex, AUTHENTICATION_ERR_CODE);
    }

    /**
     * Handle access denied exception.
     *
     * @param ex the ex
     * @return the error info
     */
    @ResponseStatus(HttpStatus.FORBIDDEN)
    @ExceptionHandler(value = AuthorizationServiceException.class)
    @ResponseBody
    public ErrorInfo handleAccessDeniedException(AuthorizationServiceException ex) {
        return handleExceptionInternal(ex, AUTHORIZATION_ERR_CODE);
    }

    /**
     * Handle illegal argument exception.
     *
     * @param ex the ex
     * @return the error info
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(value = IllegalArgumentException.class)
    @ResponseBody
    public ErrorInfo handleIllegalArgumentException(IllegalArgumentException ex) {
        return handleExceptionInternal(ex, ILLEGAL_ARGS_ERR_CODE);
    }

    /**
     * Handle response status exception.
     *
     * @param ex the ex
     * @return the response entity
     */
    @ExceptionHandler(value = ResponseStatusException.class)
    public ResponseEntity<ErrorInfo> handleResponseStatusException(ResponseStatusException ex) {
        ErrorInfo errorInfo = handleExceptionInternal(ex, RESPONSE_STATUS_ERR_CODE);
        return new ResponseEntity<>(errorInfo, ex.getStatus());
    }

    /**
     * Handle jdbc update affected incorrect number of rows exception.
     *
     * @param ex the ex
     * @return the error info
     */
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(value = JdbcUpdateAffectedIncorrectNumberOfRowsException.class)
    @ResponseBody
    public ErrorInfo handleJdbcUpdateAffectedIncorrectNumberOfRowsException(Exception ex) {
        return handleExceptionInternal(ex, JDBC_UPDATE_INCORRECT_NUMBER_OF_ROWS_ERR_CODE);
    }

    /**
     * Handle validation exception.
     *
     * @param ex the ex
     * @return the error info
     */
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(value = UniqueKeyViolationExceptionFields.class)
    @ResponseBody
    public ErrorInfo handleValidationException(UniqueKeyViolationExceptionFields ex) {
        return handleExceptionWithErrorDetailsInternal(ex, UNIQUE_KEY_VIOLATION_ERR_CODE);
    }

    /**
     * Handle duplicate key exception.
     *
     * @param ex the ex
     * @return the error info
     */
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(value = DuplicateKeyException.class)
    @ResponseBody
    public ErrorInfo handleDuplicateKeyException(DuplicateKeyException ex) {
        return handleExceptionInternal(ex, UNIQUE_KEY_VIOLATION_ERR_CODE);
    }

    /**
     * Handle reference version limit exceeded exception.
     *
     * @param ex the ex
     * @return the error info
     */
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(value = ReferenceVersionLimitExceededException.class)
    @ResponseBody
    public ErrorInfo handleReferenceVersionLimitExceededException(ReferenceVersionLimitExceededException ex) {
        return handleExceptionInternal(ex, REF_VER_SIZE_LIMIT_EXCEEDED_ERR_CODE);
    }

    /**
     * Handle exception.
     *
     * @param ex the ex
     * @return the error info
     */
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public ErrorInfo handleException(Exception ex) {
        return handleExceptionInternal(ex, GENERAL_ERR_CODE);
    }

    /**
     * Handle exception.
     *
     * @param ex the ex
     * @return the error info
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(value = LockException.class)
    @ResponseBody
    public ErrorInfo handleException(LockException ex) {
        return handleExceptionInternal(ex, KEY_LOCKED_ERR_CODE);
    }

    /**
     * Handle exception.
     *
     * @param ex the ex
     * @return the error info
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(value = ConstraintViolationException.class)
    @ResponseBody
    public ErrorInfo handleException(ConstraintViolationException ex) {
        List<ErrorDetail> errorDetails = new ArrayList<>();
        for (ConstraintViolation<?> constraintViolation : ex.getConstraintViolations()) {
            errorDetails.add(new ErrorDetail(FIELD_VALIDATION_ERR_CODE, getPropertyPath(constraintViolation.getPropertyPath().toString()),
                    constraintViolation.getMessage()));
        }
        return handleExceptionInternal(ex, errorDetails);
    }

    /** The wrapper list key. */
    private final String WRAPPER_LIST_KEY = "wrapperList";

    /**
     * Gets the property path.
     *
     * @param originPath the origin path
     * @return the property path
     */
    private String getPropertyPath(String originPath) {
        if (originPath.startsWith(WRAPPER_LIST_KEY)) {
            return originPath.substring(WRAPPER_LIST_KEY.length(), originPath.length());
        }
        return originPath;
    }

    /**
     * Handle exception.
     *
     * @param ex the ex
     * @return the error info
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(value = BadRequestException.class)
    @ResponseBody
    public ErrorInfo handleException(BadRequestException ex) {
        return handleExceptionInternal(ex, BAD_REQUEST_ERR_CODE);
    }

    /**
     * Handle exception.
     *
     * @param ex the ex
     * @return the error info
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(value = FeignException.class)
    @ResponseBody
    public ErrorInfo handleException(FeignException ex) {
        // get the error message by convert back to badrequestexception
        String exBody = ex.contentUTF8();
        ErrorInfo errorInfo = null;
        try {
            // de-ser back error info
            errorInfo = objectMapper.readValue(exBody, ErrorInfo.class);
        } catch (IOException e) {
            log.trace("Ignoring unexpected error", e);
        }
        // return original errorInfo
        if (errorInfo != null) {
            return errorInfo;
        } else {
            // else throw bad request with ex message
            throw new BadRequestException(ex.getMessage());
        }
    }

    /**
     * Handle exception internal.
     *
     * @param ex        the ex
     * @param errorCode the error code
     * @return the error info
     */
    private ErrorInfo handleExceptionInternal(Exception ex, String errorCode) {
        return handleExceptionInternal(ex, Arrays.asList(new ErrorDetail(errorCode, null, ex.getMessage())));
    }

    /**
     * Handle exception with error details internal.
     *
     * @param ex        the ex
     * @param errorCode the error code
     * @return the error info
     */
    private ErrorInfo handleExceptionWithErrorDetailsInternal(FieldsValidationException ex, String errorCode) {
        List<ErrorDetail> errorDetails = new ArrayList<>();
        for (String fieldName : ex.getFieldList()) {
            ErrorDetail errorDetail = new ErrorDetail(errorCode, fieldName, ex.getMessage());
            errorDetails.add(errorDetail);
        }
        return handleExceptionInternal(ex, errorDetails);
    }

    /**
     * Handle exception internal.
     *
     * @param ex           the ex
     * @param errorDetails the error details
     * @return the error info
     */
    private ErrorInfo handleExceptionInternal(Exception ex, List<ErrorDetail> errorDetails) {
        log.error(ex.getMessage(), ex);
        Context context = ContextHolder.getOrCreate();
        return new ErrorInfo(context.getTransId().toString(), Instant.now(), errorDetails);
    }

}
