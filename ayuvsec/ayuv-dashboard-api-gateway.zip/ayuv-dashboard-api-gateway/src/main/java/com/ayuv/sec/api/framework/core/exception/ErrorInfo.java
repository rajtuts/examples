package com.ayuv.sec.api.framework.core.exception;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import com.ayuv.sec.api.framework.core.utils.LocalInstantDeserializer;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ErrorInfo.
 * 

 * 
 */
@Data
@NoArgsConstructor
public class ErrorInfo {

    /** The trans id. */
    private String transId;

    /** The error details. */
    private List<ErrorDetail> errorDetails = new ArrayList<>();

    /** The timestamp. */
    @JsonDeserialize(using = LocalInstantDeserializer.class)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+0")
    private Instant timestamp;

    /**
     * Instantiates a new error info.
     *
     * @param transId      the trans id
     * @param timestamp    the timestamp
     * @param errorCode    the error code
     * @param errorMessage the error message
     */
    public ErrorInfo(String transId, Instant timestamp, String errorCode, String errorMessage) {
        this.transId = transId;
        this.timestamp = timestamp;
        ErrorDetail errorDetail = new ErrorDetail(errorCode, null, errorMessage);
        this.errorDetails.add(errorDetail);
    }

    /**
     * Instantiates a new error info.
     *
     * @param transId      the trans id
     * @param timestamp    the timestamp
     * @param errorDetails the error details
     */
    public ErrorInfo(String transId, Instant timestamp, List<ErrorDetail> errorDetails) {
        this.transId = transId;
        this.timestamp = timestamp;
        if (errorDetails == null) {
            this.errorDetails = new ArrayList<>();
        } else {
            this.errorDetails = new ArrayList<>(errorDetails);
        }
    }
}
