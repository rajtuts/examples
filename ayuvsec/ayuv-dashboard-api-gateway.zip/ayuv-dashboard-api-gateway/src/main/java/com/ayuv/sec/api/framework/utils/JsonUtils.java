package com.ayuv.sec.api.framework.utils;

import java.io.IOException;
import java.io.InputStream;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * The Class JsonUtils.
 * 

 * 
 */
public class JsonUtils {

    private JsonUtils() {
    }

    /**
     * The Constant jsonMapper.
     */
    private static final ObjectMapper jsonMapper = new ObjectMapper().setSerializationInclusion(Include.NON_NULL)
            .setSerializationInclusion(Include.NON_EMPTY);

    /**
     * Read value.
     *
     * @param <T>       the generic type
     * @param json      the json
     * @param classType the class type
     * @return the t
     * @throws JsonParseException   the json parse exception
     * @throws JsonMappingException the json mapping exception
     * @throws IOException          Signals that an I/O exception has occurred.
     */
    public static <T> T readValue(String json, Class<T> classType) throws JsonParseException, JsonMappingException, IOException {
        return jsonMapper.readValue(json, classType);
    }

    /**
     * Read value.
     *
     * @param <T>       the generic type
     * @param json      the json
     * @param classType the class type
     * @return the t
     * @throws JsonParseException   the json parse exception
     * @throws JsonMappingException the json mapping exception
     * @throws IOException          Signals that an I/O exception has occurred.
     */
    public static <T> T readValue(InputStream json, Class<T> classType) throws JsonParseException, JsonMappingException, IOException {
        return jsonMapper.readValue(json, classType);
    }

    /**
     * Write value as string.
     *
     * @param obj the obj
     * @return the string
     * @throws JsonProcessingException the json processing exception
     */
    public static String writeValueAsString(Object obj) throws JsonProcessingException {
        return jsonMapper.writeValueAsString(obj);
    }

}
