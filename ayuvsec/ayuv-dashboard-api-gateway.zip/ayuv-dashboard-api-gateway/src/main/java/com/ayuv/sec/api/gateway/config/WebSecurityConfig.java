package com.ayuv.sec.api.gateway.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

/**
 * The Class WebSecurityConfig.
 * 

 * 
 */
@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    /*
     * @see org.springframework.security.config.annotation.web.configuration.
     * WebSecurityConfigurerAdapter#configure(org.springframework.security.config.
     * annotation.web.builders.HttpSecurity)
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.httpBasic().disable().csrf().disable().headers().frameOptions().and().contentSecurityPolicy(getCSPolicy());
    }

    @Override
    public void configure(WebSecurity web) {
        web.ignoring().antMatchers("/assets/**", "/build/**");
    }

    public String getCSPolicy() {
        /**
         * Starter Policy This policy allows images, scripts, AJAX, form actions, and CSS from the same
         * origin, and does not allow any other resources to load (eg object, frame, media, etc). It is a
         * good starting point for many sites.
         * 
         * Reference: https://content-security-policy.com/
         */
        return "default-src 'none'; script-src 'self'; connect-src 'self'; img-src 'self'; style-src 'self';base-uri 'self';form-action 'self'";
    }
}
