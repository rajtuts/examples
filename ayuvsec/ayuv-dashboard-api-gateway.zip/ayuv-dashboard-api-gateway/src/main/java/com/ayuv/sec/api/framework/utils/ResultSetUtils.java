package com.ayuv.sec.api.framework.utils;

import java.sql.ResultSet;
import java.time.Instant;

import lombok.SneakyThrows;

/**
 * The Class ResultSetUtils.
 * 

 * 
 */
public class ResultSetUtils {

    /**
     * Gets the instant.
     *
     * @param rs    the rs
     * @param field the field
     * @return the instant
     */
    @SneakyThrows
    public static Instant getInstant(ResultSet rs, String field) {
        return rs.getTimestamp(field) == null ? null : rs.getTimestamp(field).toInstant();
    }
}
