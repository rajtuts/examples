package com.ayuv.sec.api.auth.utils;

import java.util.Base64;

/**
 * The Class BasicAuthenticationUtil.
 * 

 */
public final class BasicAuthenticationUtil {

    /**
     * Instantiates a new basic authentication util.
     */
    private BasicAuthenticationUtil() {
    }

    /**
     * Generate basic autentication header.
     *
     * @param userName     the user name
     * @param userPassword the user password
     * @return the string
     */
    public static String generateBasicAutenticationHeader(String userName, String userPassword) {
        byte[] encodedBytes = Base64.getEncoder().encode((userName + ":" + userPassword).getBytes());
        return "Basic " + new String(encodedBytes);
    }

}
