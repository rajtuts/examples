package com.ayuv.sec.api.gateway.wrapper;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;

import javax.servlet.ServletOutputStream;

/**
 * The Class ByteArrayPrinter.
 * 

 * 
 */
public class ByteArrayPrinter {

    /** The baos. */
    private ByteArrayOutputStream baos = new ByteArrayOutputStream();

    /** The pw. */
    private PrintWriter pw = new PrintWriter(baos);

    /** The sos. */
    private ServletOutputStream sos = new ByteArrayServletStream(baos);

    /**
     * Gets the writer.
     *
     * @return the writer
     */
    public PrintWriter getWriter() {
        return pw;
    }

    /**
     * Gets the stream.
     *
     * @return the stream
     */
    public ServletOutputStream getStream() {
        return sos;
    }

    /**
     * To byte array.
     *
     * @return the byte[]
     */
    public byte[] toByteArray() {
        return baos.toByteArray();
    }

}