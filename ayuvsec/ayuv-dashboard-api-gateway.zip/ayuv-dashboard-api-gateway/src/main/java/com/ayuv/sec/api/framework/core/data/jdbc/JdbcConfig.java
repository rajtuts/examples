package com.ayuv.sec.api.framework.core.data.jdbc;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * The Class JdbcConfig.
 * 

 * 
 */
@Configuration
public class JdbcConfig {

    /**
     * Jdbc template.
     *
     * @param hikariDataSource the hikari data source
     * @return the jdbc template ext
     */
    @Bean(name = "jdbcTemplate")
    public JdbcTemplateExt jdbcTemplate(HikariDataSource hikariDataSource) {
        return new JdbcTemplateExt(hikariDataSource);
    }
}
